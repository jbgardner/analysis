/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: 'class',
  theme: {
    extend: {
      backgroundImage: {
        "grad_lightBlue":
          "linear-gradient(111.69deg, rgba(93, 105, 210, 0.22) -13.86%, rgba(93, 105, 210, 0.1) 109.87%)",
        grad_border:
          "linear-gradient(110.08deg, rgba(255, 255, 255, 0.3) -13.86%, rgba(255, 255, 255, 0) 105.42 %)",
      },
      colors: {
        blueish: "rgba(93, 105, 210, 1)",
        darkfg: "rgba(12, 21, 31, 1)",
        darkbg: '#000415',
        darkblue: "rgb(20,25,61)",
        yellowish: "rgba(196, 198, 89, 1)",
        lightgray: "rgb(255 255 255 / 0.8)",
        featurebg: "#12142C",
        accents: "#14162d",
        prominenttext: "rgb(66,158,89)",
        inputColor: "rgb(44,46,65)"
      },
      maxWidth: {
        maximum: '90rem'
      },
      fontSize: {
        title: ["3rem", "3.5rem"],
        title1: ["2.5rem", "3rem"],
        title2: ["1.8rem", "2.3rem"],
      },
      gap: {
        addDif: '1.25rem',
      },
      boxShadow: {
        'box': '0px 0px 4.5px 0.8px',
      },
      screens: {
        xs: '440px'
      }
    }
  },
  // eslint-disable-next-line no-undef, @typescript-eslint/no-var-requires
  plugins: [require('@headlessui/tailwindcss')({ prefix: 'ui' })]
}



