import { ThemeProvider } from "@emotion/react"
import Router from "./Router"
import Toast from "./Components/Common/Toast"
import "./Styles/App.css"
import { createTheme } from "@mui/material"
import { AuthContextProvider } from "./Context/Auth.Context"

function App() {
   const theme = createTheme({
      palette: {
         mode: "dark",
      },
   })
   return (
      <AuthContextProvider>
         <ThemeProvider theme={theme}>
            <Router />
            <Toast />
         </ThemeProvider>
      </AuthContextProvider>
   )
}

export default App
