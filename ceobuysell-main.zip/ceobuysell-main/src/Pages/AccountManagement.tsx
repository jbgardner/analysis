//hooks
import { useCallback, useEffect, useState } from "react"
import { useAuth } from "../Hooks/useAuth"
import { useNavigate } from "react-router-dom"

// types
import Loader from "../Components/Common/Loader"
import toast from "react-hot-toast"
import { AccountCard } from "../Components/AccountManagemnet/AccountCard"
import { NotificationCard } from "../Components/AccountManagemnet/NotificationCard"
import supabase from "../Services/auth.service"
import { defaultSettings } from "../utils/Constants"
import { settingsT } from "../utils/interfaces&Types"
import "../Styles/accountManagement.css"
import { CustomNotificationsMapper } from "../Components/AccountManagemnet/CustomNotificationsMapper"
import { useSearch } from "../Hooks/useSearch"

export function AccountManagement() {
   const {
      user,
      setUser,
      logout,
      loading,
      setModelIndex,
      setOpenModel,
      customNotifications,
   } = useAuth()

   const { fetching } = useSearch()

   const [settings, setSettings] = useState(
      user ? user.settings : defaultSettings
   )
   const navigate = useNavigate()

   useEffect(() => {
      if (!user && !loading) {
         navigate("/search")
         setModelIndex(0)
         setOpenModel(true)
         toast.error("Please Login to continue")
      }
      if (user) setSettings(user.settings)
   }, [user, loading])

   const handleAddNumber = () => {
      setOpenModel(true)
      setModelIndex(2)
   }

   const settingsChaanged = () => {
      if (!user) return false
      const settingsextend: settingsT & {
         [key: string]: boolean
      } = settings

      return Object.entries(user.settings).some(
         ([key, value]) => value !== settingsextend[key]
      )
   }

   const updateSettings = useCallback(async () => {
      if (user) {
         const { error } = await supabase
            .from("users")
            .update({
               settings,
            })
            .eq("id", user.user_id)

         if (error) {
            throw new Error(error.message)
         }

         setUser({ ...user, settings })
      }
   }, [user, settings, setUser])

   useEffect(() => {
      if (settingsChaanged())
         toast.promise(
            updateSettings(),
            {
               loading: "Updating...",
               success: "Successfully updated",
               error: (error) =>
                  error.message || "Something went wrong Please try again",
            },
            { position: "top-center", duration: 1500 }
         )
   }, [settings])

   if (!user)
      return (
         <div className=" grid gap-6 ">
            <div className=" grid lg:grid-cols-[26rem,1fr] gap-6 ">
               <section className=" w-[95%] h-[30rem] xs:w-[26rem] mx-auto sm:mx-0 bg-darkfg rounded-2xl ">
                  {loading && <Loader size={30} />}
               </section>
               <section className="w-full h-[30rem] mx-auto sm:mx-0 bg-darkfg rounded-lg p-4 md:p-6">
                  {loading && <Loader size={30} />}
               </section>
            </div>
            <section className="w-full grid gap-4 h-[30rem] mx-auto sm:mx-0 bg-darkfg rounded-lg p-4 md:p-6">
               {loading && <Loader size={30} />}
            </section>
         </div>
      )

   return (
      <div className=" grid gap-6 ">
         <div className=" grid lg:grid-cols-[26rem,1fr] gap-6 ">
            {/* ============================= MY ACCOUNT =============================*/}

            <AccountCard
               logout={logout}
               user={user}
               settings={settings}
               setSettings={setSettings}
               handleAddNumber={handleAddNumber}
            />
            {/* =================================== MY NOTIFICATIONS ===================================*/}
            <NotificationCard
               settings={settings}
               setSettings={setSettings}
               user={user}
               setUser={setUser}
               handleAddNumber={handleAddNumber}
            />
         </div>

         <CustomNotificationsMapper
            handleAddNumber={handleAddNumber}
            user={user}
            customNotifications={customNotifications}
            fetching={fetching}
         />
      </div>
   )
}
