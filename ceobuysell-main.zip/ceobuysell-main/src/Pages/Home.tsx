import { Footer } from "../Components/Header&fFooter/Footer"
import { Header } from "../Components/Header&fFooter/Header"
import { Blogs } from "../Components/Home/Blogs"
import { Features } from "../Components/Home/Features"
import { Hero } from "../Components/Home/Hero"
import { HowItWorks } from "../Components/Home/HowItWorks"
import { Pricing } from "../Components/Home/Pricing"
import { Stories } from "../Components/Home/Stories"
import { Testimonials } from "../Components/Home/Testimonials"
import { HomeContainer } from "../Components/Containers/HomeContainer"
import "../Styles/searchBar.css"

export default function Home() {
   return (
      <HomeContainer>
         <main className=" w-full h-full relative md:bg-darkbg/20">
            <Header />
            <Hero />
            <HowItWorks />
            <Features />
            <Pricing />
            <Stories />
            <Testimonials />
            <Blogs />
            <Footer addSearchBar />
         </main>
      </HomeContainer>
   )
}
