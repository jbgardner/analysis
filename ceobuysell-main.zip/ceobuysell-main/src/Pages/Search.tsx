import { FC, useEffect, useState } from "react"
import { Link, useLocation, useNavigate } from "react-router-dom"
import { getSearch } from "../Services/user.services"
import { useQuery } from "@tanstack/react-query"
import Loader from "../Components/Common/Loader"
import { removeDuplicates, urlsInitializer } from "../utils/Helper"
import { TransactionCard } from "../Components/Search/TransactionCard"
import Filters from "../Components/Search/Filters"
import { searchDataT } from "../utils/interfaces&Types"
import { useAuth } from "../Hooks/useAuth"
import { AddNotificationAndWatchlist } from "../Components/Search/AddNotificationAndWatchlist"
import { FormControl, MenuItem, Select, SelectChangeEvent } from "@mui/material"
import { Pager } from "../Components/Search/Pager"

export const Search = () => {
   const location = useLocation()
   const searchParams = new URLSearchParams(location.search)
   const navigate = useNavigate()
   const [filters, setFilter] = useState<searchDataT>(
      urlsInitializer(searchParams)
   )
   const [openFilterModal, setOpenFilterModal] = useState<boolean>(false)
   const [watchlistFilteredTickers, setWatchlistFilteredTickers] = useState<
      string[] | null
   >(null)

   const { user, setUser, setModelIndex, setOpenModel } = useAuth()

   // Function to set page offset in URL and update state
   const pageSetter = (value: number) => {
      const searchParams = new URLSearchParams(location.search)
      searchParams.set("offset", value.toString())
      navigate(`?${searchParams.toString()}`)
      setFilter({ ...filters, offset: value })
   }

   // Effect to update state with filters based on URL parameters
   useEffect(() => {
      const newFilters = urlsInitializer(new URLSearchParams(location.search))
      setFilter(newFilters)
   }, [location.search])

   // Effect to update filtered tickers when filters or user change
   useEffect(() => {
      setWatchlistFilteredTickers(availableTickers())
   }, [filters, user])

   // Check if there are specific filters excluding "offset" and "ticker"
   const hasSpecificFilters = Object.entries(filters).some(
      ([key, value]) =>
         !["offset", "ticker", "transaction_type"].includes(key) &&
         value !== undefined
   )

   // Check if there are any filters excluding "offset"
   const hasFilters = Object.entries(filters).some(
      ([key, value]) => key !== "offset" && value !== undefined
   )

   // Reset filters and navigate to the search page
   const handleReset = () => navigate(`/search`)

   // Get tickers available based on user's watchlist and applied filters
   const availableTickers = () => {
      const { ticker } = filters

      if (ticker && user && user.watchlist) {
         const { watchlist } = user

         let resultantFilters = removeDuplicates(ticker.split(","))
         resultantFilters = resultantFilters.filter(
            (value) => !watchlist.includes(value)
         )

         // Return null if there are no available tickers after filtering
         return resultantFilters.length > 0 ? resultantFilters : null
      }
      return null
   }

   // Query to fetch search results based on filters
   const transactionQuery = useQuery({
      queryFn: () =>
         getSearch(filters).then((res) => {
            return res.data
         }),
      queryKey: ["transactions", filters],
   })

   // ==================== ERROR ====================
   if (transactionQuery.isError)
      return (
         <div className=" grid gap-6 md:gap-10 ">
            <section className=" grid justify-center w-full h-full pb-[20%]">
               <div className=" grid gap-6 relative bg-darkfg px-4 py-6 lg:px-5 lg:py-8 rounded-xl w-full">
                  <p className=" text-xl  lg:text-2xl font-extrabold text-center">
                     Sorry Someting went wrong
                  </p>
                  <p className="text-center lg:text-xl">
                     Please contact us on info@ceobuysell.com
                  </p>
               </div>
            </section>
         </div>
      )
   // ==================== LOADING ====================
   if (transactionQuery.isLoading)
      return (
         <div className=" grid gap-6 md:gap-10 ">
            <section className="w-full h-[30rem]">
               <Loader size={40} />
            </section>
         </div>
      )

   return (
      <div className=" grid gap-6 md:gap-10 ">
         {/* ==================== FOUND ADD TO NOTIFICATION ==================== */}
         {transactionQuery.data &&
            user &&
            transactionQuery.data.meta &&
            transactionQuery.data.meta.total.value > 0 &&
            (hasSpecificFilters || watchlistFilteredTickers !== null) && (
               <AddNotificationAndWatchlist
                  filters={filters}
                  hasSpecificFilters={hasSpecificFilters}
                  user={user}
                  setUser={setUser}
                  watchlistFilteredTickers={watchlistFilteredTickers}
               />
            )}
         {/* ==================== FILTERS ==================== */}
         <section className=" flex flex-wrap items-end justify-between gap-3 md:gap-5">
            {/* total results  */}
            <div>
               {transactionQuery.data && filters.transaction_type && (
                  <TracsectionType
                     transactionType={filters.transaction_type}
                     setTransactionType={(transaction_type: string) => {
                        searchParams.set("offset", "0")
                        searchParams.set("transaction_type", transaction_type)
                        navigate(`?${searchParams}`)
                     }}
                  />
               )}
            </div>
            <div className="flex flex-wrap items-end gap-3 md:gap-5">
               {transactionQuery.data && transactionQuery.data.meta && (
                  <p className=" text-lg  text-white/70 whitespace-nowrap">
                     <span className="">
                        {transactionQuery.data.meta.total.value.toLocaleString()}
                     </span>
                     <span className="italic"> results</span>
                  </p>
               )}
               <button
                  onClick={() => setOpenFilterModal(!openFilterModal)}
                  title="Filters"
                  className="w-fit flex gap-2 items-center justify-center border border-blueish transition-all duration-[0.2s] hover:bg-blueish px-2 py-1 rounded-lg"
               >
                  Advance Search
               </button>
               {hasFilters && transactionQuery.data && (
                  <button
                     className=" w-fit xs:text-lg flex items-center justify-center transition-all duration-[0.2s] ease-in-out text-white/60 hover:text-blueish underline underline-offset-4 py-1 rounded-xl "
                     type="button"
                     onClick={handleReset}
                  >
                     Clear search
                  </button>
               )}
            </div>
         </section>
         {/* ==================== TRANSACTIONAL CARD ==================== */}
         {transactionQuery.data && transactionQuery.data.data && (
            <TransactionCard transactionalData={transactionQuery.data.data} />
         )}
         {/* ==================== NOT FOUND ==================== */}
         {transactionQuery.data &&
            (!transactionQuery.data.meta ||
               (transactionQuery.data.meta &&
                  transactionQuery.data.meta.total.value <= 0)) && (
               <section className=" grid justify-center w-full h-full pb-[20%]">
                  <div className=" grid gap-6 relative bg-darkfg px-4 py-6 lg:px-5 lg:py-8 rounded-xl w-full">
                     <p className=" text-xl  lg:text-2xl font-extrabold text-center">
                        No results for this search
                     </p>
                     <p className="text-center lg:text-xl">
                        We have not found any disclosures matching this search.
                        Don't forget we only look for CEO purchasing and selling
                        at market price (no bonuses, no stock options, no
                        gifts).
                     </p>
                     <p className=" flex flex-wrap w-full justify-center gap-2 lg:text-xl">
                        {user && user.isPro ? (
                           <Link
                              to={"/dashboard"}
                              className=" text-blueish hover:underline "
                           >
                              Set up a notification
                           </Link>
                        ) : (
                           <span
                              onClick={() => {
                                 setModelIndex(0)
                                 setOpenModel(true)
                              }}
                              className=" text-blueish hover:underline cursor-pointer "
                           >
                              Set up a notification
                           </span>
                        )}
                        to get updated in real-time when a new result matches
                        this search.
                     </p>
                  </div>
               </section>
            )}

         {/* ==================== PAGINATION ==================== */}
         {transactionQuery.data && transactionQuery.data.meta && (
            <Pager
               offset={filters.offset ? filters.offset : 0}
               pageSetter={pageSetter}
               total={transactionQuery.data.meta.total}
            />
         )}
         {/* ==================== FILTERS MODAL ==================== */}
         <Filters
            open={openFilterModal}
            setOpen={setOpenFilterModal}
            filters={filters}
            setFilter={setFilter}
            disabled={user ? !user.isPro : true}
         />
      </div>
   )
}

const TracsectionType: FC<{
   transactionType: string
   setTransactionType: (arg: string) => void
}> = ({ transactionType, setTransactionType }) => {
   const handleChange = (event: SelectChangeEvent) => {
      setTransactionType(event.target.value)
   }
   return (
      <FormControl variant="standard" sx={{ minWidth: 100 }} size="small">
         <Select
            value={transactionType}
            label="transactionType"
            onChange={handleChange}
         >
            <MenuItem
               // style={{
               //    backgroundColor: "rgb(44 ,46, 65)",
               // }}
               value={"S"}
            >
               Sell
            </MenuItem>
            <MenuItem
               // style={{
               //    backgroundColor: "rgb(44 ,46, 65)",
               // }}
               value={"P"}
            >
               Purchase
            </MenuItem>
         </Select>
      </FormControl>
   )
}
