// Components
import { Header } from "../Components/Header&fFooter/Header"
import { Footer } from "../Components/Header&fFooter/Footer"
import { BlogSection } from "../Components/Blog/BlogSection"

// assets
import highlight from "../assets/Images/highlighter.webp"
import "../Styles/singleBlog.css"

// layout
import { useScroll, useTransform, motion } from "framer-motion"
import { useEffect, useRef, useState } from "react"

export function Blog() {
   const { scrollYProgress } = useScroll()
   const y = useTransform(scrollYProgress, [0, 1], ["0%", "40%"])
   const [height, setHeight] = useState<null | number>(null)

   const mainRf = useRef<HTMLDivElement>(null)

   useEffect(() => {
      const getDivHeight = mainRf.current ? mainRf.current.offsetHeight : null
      setHeight(getDivHeight)
   }, [])

   return (
      <div
         className="w-full mx-auto max-w-[1800px] h-full bg-darkbg text-white relative overflow-clip z-0"
         ref={mainRf}
      >
         <main className=" w-full h-full ">
            <Header />
            <BlogSection />
            <Footer addSearchBar />
            <motion.div
               className=" fixed max-w-[1800px] hidden md:block h-full w-full inset-0 mx-auto -z-10"
               style={{
                  y,
                  backgroundImage: `url(${highlight})`,
                  backgroundSize: "120% 120%",
                  backgroundPosition: "center",
                  maxHeight: `${height}px`,
               }}
            ></motion.div>
         </main>
      </div>
   )
}
