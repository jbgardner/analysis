// @tryghost__content-api.d.ts
declare module "@tryghost/content-api"
declare module "@types/tryghost__content-api"
