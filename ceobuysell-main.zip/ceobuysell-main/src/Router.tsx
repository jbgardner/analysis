import { Routes, Route } from "react-router-dom"
import Landing from "./Pages/Home"
import { Blog } from "./Pages/Blog"
import { AccountManagement } from "./Pages/AccountManagement"
import { Search } from "./Pages/Search"
import { SearchContainer } from "./Components/Containers/SearchContainer"

import PrivacyPolicy from "./Components/Site/privacy"
import TermsAndConditions from "./Components/Site/terms"

export default function Router() {
   return (
      <Routes>
         <Route path="/" element={<Landing />} />
         <Route path="/blog/:slug" element={<Blog />} />

         <Route path="/" element={<SearchContainer />}>
            <Route path="search" element={<Search />} />
            <Route path="search/*" element={<Search />} />
            <Route path="dashboard" element={<AccountManagement />} />
            <Route path="dashboard/*" element={<AccountManagement />} />
         </Route>
         <Route path="/*" element={<Landing />} />
         <Route path="/terms-and-conditions" element={<TermsAndConditions />} />
         <Route path="/privacy-policy" element={<PrivacyPolicy />} />
      </Routes>
   )
}
