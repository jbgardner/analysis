import { useEffect, useState } from "react"
export function useDirection() {
   const [scrollInfo, setScrollInfo] = useState<{
      scrollValue: number
      // scrollDirection: "up" | "down" | "stop"
   }>({
      scrollValue: 0,
      // scrollDirection: "stop",
   })

   useEffect(() => {
      let rafId: number

      const handleScroll = () => {
         cancelAnimationFrame(rafId)

         rafId = requestAnimationFrame(() => {
            const scrollValue = window.scrollY
            // const scrollDirection =
            //    scrollValue > scrollInfo.scrollValue ? "down" : "up"
            setScrollInfo({ scrollValue })
         })
      }

      window.addEventListener("scroll", handleScroll)

      return () => {
         window.removeEventListener("scroll", handleScroll)
         cancelAnimationFrame(rafId)
      }
   }, [scrollInfo])

   return scrollInfo
}
