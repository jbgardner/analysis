import { useOutletContext } from "react-router-dom"
import { SearchContextT } from "../utils/interfaces&Types"

export function useSearch() {
   return useOutletContext<SearchContextT>()
}
