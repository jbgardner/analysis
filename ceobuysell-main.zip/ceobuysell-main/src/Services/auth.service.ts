// ======= server =======
import axiosInstance from "./axios.instance"

export const checkoutSession = async (data: {
   user_id: string
   plan: string
}) => {
   return await axiosInstance.post("stripe/checkout-session/", data)
}

export const verifySubsription = (subscription_id: string) => {
   return axiosInstance.get(
      `stripe/verify-subscription?subscription_id=${subscription_id}`
   )
}

export const stripeUserPortal = (customer_id: string) => {
   return axiosInstance.get(
      `/stripe/customer_portal?customer_id=${customer_id}`
   )
}

// ======= Supabase ======
import { createClient } from "@supabase/supabase-js"

const supabaseUrl = "https://dlmlrsccqledxkuvvbrw.supabase.co"
const supabaseKey = import.meta.env.VITE_PUBLIC_SUPABASE_KEY

const supabase = createClient(supabaseUrl, supabaseKey)

export default supabase
