// import { mapSearchDataToQueryParams } from "../utils/Helper"
import { searchDataT } from "../utils/interfaces&Types"
import axiosInstance from "./axios.instance"

export const updateUser = (data: { user_id: string }) => {
   return axiosInstance.post("/", data)
}

export const getSearch = (data: searchDataT) => {
   return axiosInstance.get("search", { params: data })
}

export const requestOtp = (data: { phone: string }) => {
   return axiosInstance.post("/phone/request_verification/", data)
}

export const verfiyOtp = (data: { phone: string; code: string }) => {
   return axiosInstance.post("/phone/verfiy/", data)
}
