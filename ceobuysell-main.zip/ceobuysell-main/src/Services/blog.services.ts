import GhostContentAPI from "@tryghost/content-api"

const url = import.meta.env.VITE_GHOST_API_URL
const key = import.meta.env.VITE_GHOST_CONTENT_KEY

const api = new GhostContentAPI({
   url: url,
   key: key,
   version: "v5.0",
})

export const getAllPosts = async () => {
   return await api.posts
      .browse({
         limit: "all",
         include: ["authors", "tags"],
      })
      .catch(() => {
         // console.log("eroor in the blogs")
         return null
      })
}

export async function getSinglePost(slug: string) {
   return await api.posts
      .read({
         slug: slug,
      })
      .catch(() => {
         return null
      })
}
