import { FC, createContext, useEffect, useState } from "react"

import supabase, { checkoutSession } from "../Services/auth.service"
import {
   AuthContextT,
   ContextPropsT,
   UserT,
   customNotificationsT,
} from "../utils/interfaces&Types"
import toast from "react-hot-toast"
import { AuthChangeEvent, Session, User } from "@supabase/supabase-js"

import axiosInstance from "../Services/axios.instance"

// context Intializer
const initialValue = {
   user: null,
   setUser: () => {},
   login: () => {},
   logout: () => {},
   register: () => {},
   loading: true,
   openModel: false,
   setOpenModel: () => {},
   modelIndex: 0,
   setModelIndex: () => {},
   customNotifications: null,
   fetchCustomNotifications: async (_id: string) => {},
}

// Context Hook
export const AuthContext = createContext<AuthContextT>(initialValue)

// Context Provider
export const AuthContextProvider: FC<ContextPropsT> = ({ children }) => {
   const [user, setUser] = useState<UserT | null>(null)
   const [loading, setLoading] = useState<boolean>(true)
   const [openModel, setOpenModel] = useState<boolean>(false)
   const [modelIndex, setModelIndex] = useState<number>(0)
   const [customNotifications, setCustomNotifications] = useState<
      customNotificationsT[] | null
   >(null)

   // Auth listner and session controls
   const handleAuthStateChange = async (
      event: AuthChangeEvent,
      session: Session | null
   ) => {
      try {
         switch (event) {
            case "INITIAL_SESSION":
            case "SIGNED_IN":
               // case "USER_UPDATED":
               // case "TOKEN_REFRESHED":
               // console.log(event)

               session ? initializeUser(session.user) : setLoading(false)
               break
            case "SIGNED_OUT":
               // console.log(event)
               setCustomNotifications(null)
               setUser(null)
               setLoading(false)
               break
            // default:
            //    console.log(event, " => ", session)
         }
      } catch (error) {
         console.error("Error in handleAuthStateChange:", error)
      }
   }

   useEffect(() => {
      const { data: authListener } = supabase.auth.onAuthStateChange(
         handleAuthStateChange
      )

      return () => {
         authListener.subscription.unsubscribe()
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
   }, [])

   // ========================================================== INITIALIZE USER ==========================================================
   const initializeUser = async (authUser: User, tries = 0) => {
      if (authUser) {
         const { data, error } = await supabase
            .from("users")
            .select("*")
            .eq("user_id", authUser.id)
            .single()

         if (error) {
            if (tries <= 1) {
               initializeUser(authUser, tries + 1)
               return
            }
            toast.error(error.message)
            logout()
            return
         }

         const {
            subscription_id,
            settings,
            id,
            customer_id,
            has_lifetime_access,
            phone,
            watchlist_notification,
            plan,
         } = data

         let isPro = has_lifetime_access

         if (!isPro && subscription_id && id) {
            //  verify subscription in stripe
            await axiosInstance
               .get(
                  `stripe/verify-subscription?subscription_id=${subscription_id}&user_id=${id}`
               )
               .then((res) => {
                  isPro = res.data.status
               })
               .catch((err) => {
                  setLoading(false)
                  console.error("\nerr ayya: ", err)
               })
         }

         const watchlist = await fetchWatchlist(id)

         setUser({
            ...user,
            user_id: id,
            id: authUser.id,
            email: authUser.email,
            name: authUser.user_metadata.name,
            settings: settings,
            phone: phone,
            subscription_id: subscription_id,
            isPro: isPro,
            watchlist,
            watchlist_notification,
            has_lifetime_access,
            customer_id: customer_id,
            plan,
         })
      }
      setLoading(false)
   }

   // ========================================================== FETCH WATCHLIST ==========================================================

   const fetchWatchlist = async (id: string) => {
      const { data, error } = await supabase
         .from("watchlist")
         .select("name,created_at")
         .eq("user_id", id)

      if (error) {
         // console.log(error)
         return
      }

      const sortedArray = data.sort(
         (a, b) =>
            convertToDate(a.created_at).getTime() -
            convertToDate(b.created_at).getTime()
      )

      let watchlist: string[] = []
      for (let index = 0; index < sortedArray.length; index++) {
         watchlist.push(sortedArray[index].name)
      }

      return watchlist
   }
   // ========================================================== FETCH CUSTOM NOTIFICATIONS ==========================================================
   const convertToDate = (isoDateString: string): Date =>
      new Date(isoDateString)

   const fetchCustomNotifications = async (id: string) => {
      const { data, error } = await supabase
         .from("custom_notifications")
         .select("*")
         .eq("user_id", id)

      if (error) return

      // Sort the array based on the "created_at" property
      const sortedArray = data.sort(
         (a, b) =>
            convertToDate(a.created_at).getTime() -
            convertToDate(b.created_at).getTime()
      )

      setCustomNotifications(sortedArray)
   }

   // ========================================================== LOGOUT ==========================================================
   const logout = async () => {
      setLoading(true)
      const { error } = await supabase.auth.signOut()

      if (error) {
         toast.error(error.message)
      }

      setLoading(false)
   }

   // ========================================================== LOGIN ==========================================================
   const login = async (credentials: { email: string; password: string }) => {
      try {
         setLoading(true)
         if (!validateCredentials(credentials)) {
            setLoading(false)
            return
         }

         // Login user
         const { error } = await supabase.auth.signInWithPassword({
            email: credentials.email,
            password: credentials.password,
         })

         if (error) {
            setLoading(false)
            toast.error(error.message)
            return
         }

         setOpenModel(false)
      } catch (error) {
         console.error(error)
         toast.error("An error occurred during login")
      }
   }

   // ========================================================== REGISTER ==========================================================
   const register = async (credentials: {
      email: string
      password: string
      name: string
      plan: string
   }) => {
      try {
         setLoading(true)

         if (!validateCredentials(credentials)) {
            setLoading(false)
            return
         }

         // Register user
         const { error, data } = await supabase.auth.signUp({
            email: credentials.email,
            password: credentials.password,
            options: {
               data: {
                  name: credentials.name,
               },
            },
         })

         if (error) {
            toast.error(error.message)
            setLoading(false)
            return
         }

         const req = { user_id: "", plan: "" }
         if (data.user?.id) {
            req.user_id = data.user?.id
            req.plan = credentials.plan
         }

         setOpenModel(false)

         const res = await checkoutSession(req)

         // Open Stripe Checkout
         window.location.href = res.data.session_url
      } catch (error) {
         toast.error("An error occurred during registration")
      }
   }

   const value = {
      user,
      setUser,
      login,
      logout,
      register,
      loading,
      openModel,
      setOpenModel,
      modelIndex,
      setModelIndex,
      customNotifications,
      fetchCustomNotifications,
   }

   return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
// ========================================================== context ended ==========================================================

// ========================================================== credentials Validater ==========================================================
const validateCredentials = (credentials: {
   email: string
   password: string
   name?: string
   plan?: string
}) => {
   // validate form
   if (Object.values(credentials).some((value) => value === "" || !value)) {
      toast.error("Please fill in all fields")
      return false
   }

   // validate email
   const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/
   if (!emailRegex.test(credentials.email)) {
      toast.error("Please enter a valid email")
      return false
   }

   return true
}
