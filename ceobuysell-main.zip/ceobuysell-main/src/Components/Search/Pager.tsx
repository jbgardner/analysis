import clsx from "clsx"
import { GoBackDoubleI, GoforwardSingleI } from "../../assets/Icons/Icons"

type PagerT = {
   offset: number
   pageSetter: (value: number) => void
   total: { value: number }
}

export function Pager({ offset, pageSetter, total }: PagerT) {
   const totalPages: number = total.value / 20
   const currentPage: number = parseInt((offset / 20).toFixed(0))

   const setPageSetter = (arg: number) => {
      pageSetter(arg * 20)
   }

   return (
      <section className=" flex flex-wrap gap-2 sm:gap-6 items-center justify-center mx-4">
         {/* Go to start */}
         {totalPages >= 5 && (
            <button
               disabled={offset <= 0}
               className="pagers"
               onClick={() => setPageSetter(0)}
            >
               <GoBackDoubleI className=" h-6 w-[1.5rem]" />
            </button>
         )}

         {/* back */}
         <button
            disabled={offset <= 0}
            className="pagers"
            onClick={() => setPageSetter(currentPage - 1)}
         >
            <GoforwardSingleI className=" h-6 w-[1.5rem]  grid items-center justify-center rotate-180" />
         </button>

         {/* 2down */}
         <button
            className={clsx("pagers ", currentPage - 2 < 0 && "hidden")}
            onClick={() => setPageSetter(currentPage - 2)}
         >
            <div className="h-6 w-fit min-w-[1.5rem] grid items-center">
               {currentPage - 2}
            </div>
         </button>
         {/* 1down */}
         <button
            onClick={() => setPageSetter(currentPage - 1)}
            className={clsx("pagers", currentPage - 1 < 0 && "hidden")}
         >
            <div className="h-6 w-fit min-w-[1.5rem] grid items-center">
               {currentPage - 1}
            </div>
         </button>
         {/* currentPage */}
         <button
            disabled
            className=" w-fit h-fit grid items-center justify-center rounded-lg opacity-60 scale-105  bg-accents shadow-lg shadow-black border-[0.5px] border-blueish p-[6px]"
         >
            <div className="h-7 w-fit min-w-[1.5rem] grid items-center md:text-lg ">
               {currentPage}
            </div>
         </button>
         {/* 1up */}
         <button
            className={clsx(
               "pagers",
               currentPage + 1 >= totalPages && "hidden"
            )}
            onClick={() => setPageSetter(currentPage + 1)}
         >
            <div className="h-6 w-fit min-w-[1.5rem] grid items-center">
               {currentPage + 1}
            </div>
         </button>
         {/* 2up */}
         <button
            onClick={() => setPageSetter(currentPage + 2)}
            className={clsx(
               "pagers",
               currentPage + 2 >= totalPages && "hidden"
            )}
         >
            <div className="h-6 w-fit min-w-[1.5rem] grid items-center">
               {currentPage + 2}
            </div>
         </button>
         {/* next */}
         <button
            className="pagers"
            disabled={offset + 20 >= total.value}
            onClick={() => setPageSetter(currentPage + 1)}
         >
            <GoforwardSingleI className=" h-6 w-[1.5rem] grid items-center justify-center" />
         </button>
         {/* Go to end */}
         {totalPages >= 5 && (
            <button
               className="pagers"
               disabled={offset + 40 >= total.value}
               onClick={() =>
                  setPageSetter(
                     parseInt(
                        (totalPages % 1 === 0
                           ? totalPages - 1
                           : totalPages
                        ).toString()
                     )
                  )
               }
            >
               <GoBackDoubleI className=" h-6 w-w-[1.5rem] rotate-180" />
            </button>
         )}
      </section>
   )
}
