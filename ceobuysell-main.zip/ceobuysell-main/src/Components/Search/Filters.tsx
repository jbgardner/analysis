// hooks
import { useNavigate } from "react-router-dom"

// components
import { Dialog, Transition } from "@headlessui/react"
import { MarketCap } from "./Filters/MarketCap"
import { DropDownContainer } from "./Filters/DropDownContainer"
import { MinMax } from "./Filters/MinMax"

// assets
import { hero, sectorsMap, sortMap } from "../../utils/Constants"
import { CloseI } from "../../assets/Icons/Icons"

// helpers
import "../../Styles/searchPage.css"
import { convertFormDataToSearchData } from "../../utils/Helper"

// interface and types
import { filtersModalPropsT } from "../../utils/interfaces&Types"
import { FC, FormEvent, Fragment } from "react"

const Filters: FC<filtersModalPropsT> = ({
   open,
   setOpen,
   filters,
   // setFilter,
   disabled,
}) => {
   const navigate = useNavigate()

   const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault()
      const data = new FormData(event.currentTarget)
      const convertedFilters = convertFormDataToSearchData(data)

      let qurey = "?"
      Object.entries(convertedFilters).forEach(([key, value]) => {
         if (qurey !== "?") qurey = qurey + "&"
         qurey = qurey + key + "=" + value
      })
      let tT = filters.transaction_type

      if (qurey !== "?") {
         qurey = qurey + "&transaction_type" + "=" + tT
      }

      navigate(`${qurey}`)

      // setFilter(convertedFilters)
      setOpen(false)
   }

   return (
      <Transition appear show={open} as={Fragment}>
         <Dialog
            as="div"
            open={open}
            className="relative z-[99999]"
            onClose={() => setOpen(false)}
         >
            <Transition.Child
               as={Fragment}
               enter="ease-out duration-300"
               enterFrom="opacity-0"
               enterTo="opacity-100"
               leave="ease-in duration-200"
               leaveFrom="opacity-100"
               leaveTo="opacity-0"
            >
               <div className="fixed inset-0 bg-black/25 backdrop-blur-[1px]" />
            </Transition.Child>

            <div className="fixed inset-0 overflow-y-auto">
               <div className="flex min-h-full items-center justify-center p-3 xs:p-4 text-center">
                  <Transition.Child
                     as={Fragment}
                     enter="ease-out duration-300"
                     enterFrom="opacity-0 translate-y-10 scale-[0.2]"
                     enterTo="opacity-100 scale-100"
                     leave="ease-in duration-300"
                     leaveFrom="opacity-100 -translate-y-10 scale-100"
                     leaveTo="opacity-0 scale-95"
                  >
                     <Dialog.Panel className="w-full xs:w-[97%] md:w-[35rem] transform rounded-lg shadow-xl shadow-black h-fit  transition-all">
                        <section className="grid h-full ">
                           <article className="relative p-4 md:p-6 w-full h-full overflow-auto rounded-2xl bg-accents pb-10">
                              <header className="flex-1 mx-auto w-full  text-white text-2xl border-b border-slate-50/50 ui-selected:border-white pb-2 mb-2">
                                 Advance Search
                              </header>
                              <form
                                 action="submit"
                                 className="  grid gap-2 md:gap-3 w-full pt-2 "
                                 onSubmit={handleSubmit}
                              >
                                 {/* ==================== sort by ==================== */}
                                 <div className="filters-container">
                                    <p className="filters-label">Sort By:</p>
                                    <DropDownContainer
                                       name="sort"
                                       defaultValue={
                                          filters.sort ? filters.sort : 1
                                       }
                                       mapingArray={sortMap}
                                    />
                                 </div>
                                 {/* ==================== Sector ==================== */}
                                 <div className="filters-container">
                                    <p className="filters-label">
                                       Sectors:
                                       {disabled && (
                                          <span className=" xs:hidden font-normal text-prominenttext ">
                                             Pro
                                          </span>
                                       )}
                                    </p>
                                    <DropDownContainer
                                       name="sector"
                                       defaultValue={
                                          filters.sector ? filters.sector : 0
                                       }
                                       disabled={disabled}
                                       mapingArray={sectorsMap}
                                    />
                                 </div>
                                 {/* ==================== Company/CEO name ==================== */}
                                 <div className="filters-container">
                                    <p className="filters-label ">
                                       Company/CEO name:
                                    </p>
                                    <input
                                       type="text"
                                       name="q"
                                       placeholder="tesla or elon"
                                       className="outline-none rounded-md px-2 py-1 sm:text-[1.1rem] bg-inputColor"
                                       defaultValue={filters.q}
                                    />
                                 </div>
                                 {/* ==================== Ticker ==================== */}
                                 <div className="filters-container">
                                    <p className="filters-label ">Tickers:</p>
                                    <input
                                       type="text"
                                       name="ticker"
                                       placeholder={hero.placeHolder}
                                       className="outline-none rounded-md px-2 py-1 sm:text-[1.1rem] bg-inputColor"
                                       defaultValue={filters?.ticker?.replace(
                                          /,/g,
                                          ", "
                                       )}
                                    />
                                 </div>
                                 {/* ==================== Market Capital ==================== */}
                                 <MarketCap
                                    name="market_cap"
                                    defaultValue={filters.market_cap}
                                    disabled={disabled}
                                 />
                                 {/* ==================== Total share ==================== */}
                                 <MinMax
                                    defaultMin={filters.total_share_min}
                                    defaultMax={filters.total_share_max}
                                    name="total_share"
                                    label="Total share"
                                 />
                                 {/* ==================== Ownership increaset ==================== */}
                                 <MinMax
                                    defaultMin={filters.ownership_increase_min}
                                    defaultMax={filters.ownership_increase_max}
                                    disabled={disabled}
                                    name="ownership_increase"
                                    label="Ownership increase"
                                 />
                                 {/* ==================== share price ==================== */}
                                 <MinMax
                                    defaultMin={filters.share_price_min}
                                    defaultMax={filters.share_price_max}
                                    name="share_price"
                                    label="Share price"
                                 />
                                 {/* ==================== share_count ==================== */}
                                 <MinMax
                                    defaultMin={filters.share_count_min}
                                    defaultMax={filters.share_count_max}
                                    name="share_count"
                                    label="Share Count"
                                 />
                                 {/* ==================== Total amount ==================== */}
                                 <MinMax
                                    defaultMin={filters.total_amount_min}
                                    defaultMax={filters.total_amount_max}
                                    name="total_amount"
                                    label="Total amount"
                                 />
                                 {/* ==================== Buttons ==================== */}
                                 <div className=" flex mx-auto w-full flex-wrap gap-2 md:gap-3 ">
                                    <button
                                       className=" mx-auto w-1/2 mt-6 sm:text-lg flex gap-2 items-center justify-center border border-blueish transition-all duration-[0.2s] ease-in-out hover:bg-blueish px-2 py-1 rounded-xl "
                                       type="submit"
                                    >
                                       Search
                                    </button>
                                 </div>
                              </form>
                           </article>

                           {/* ==================== close button ==================== */}
                           <button
                              className="absolute top-5 right-5 group "
                              title="Close"
                              onClick={() => setOpen(false)}
                           >
                              <CloseI className=" fill-white group-hover:fill-slate-200 h-7 w-7" />
                           </button>
                        </section>
                     </Dialog.Panel>
                  </Transition.Child>
               </div>
            </div>
         </Dialog>
      </Transition>
   )
}

export default Filters
