import clsx from "clsx"
import {
   addPlus,
   getConciseDateAndTime,
   getTimeDifference,
   removeExtraFloat,
} from "../../utils/Helper"
import { transactionsT } from "../../utils/interfaces&Types"

export const TransactionCard = ({
   transactionalData,
}: {
   transactionalData: transactionsT[]
}) => (
   <section className=" grid gap-4">
      {transactionalData.map((data, index) => {
         const {
            one_month_return,
            one_week_return,
            six_months_return,
            share_price,
            ceo_name,
            change_in_shares_percentage,
            company_name,
            ticker,
            total_amount_spent,
            total_shares,
            disclosed_date,
            total_shares_after_transaction,
            transaction_type,
            link,
         } = data

         // DATE TIME ADJUSTING
         const dateTime = getConciseDateAndTime(disclosed_date)

         // RETURNS ADJUSTING
         const weekReturn = addPlus(removeExtraFloat(one_week_return))
         const monthReturn = addPlus(removeExtraFloat(one_month_return))
         const halfReturn = addPlus(removeExtraFloat(six_months_return))
         // SHARE PRICE ADJUSTING
         const sharePrice = removeExtraFloat(share_price)
         // TOTAL SHARES ADJUSTING
         const totalShares = removeExtraFloat(total_shares)
         // CHANGE IN SHARES % ADJUSTING
         const changeInSharesPercentage = removeExtraFloat(
            change_in_shares_percentage
         )

         const TotalAmoutSpent = removeExtraFloat(total_amount_spent)

         return (
            <div
               key={index}
               className=" grid gap-4 relative bg-darkfg shadow-lg shadow-black/80 border border-white/10 p-4 lg:p-5 rounded-lg w-full h-fit"
            >
               {/* ===== time ===== */}
               <header className=" flex justify-between w-full">
                  <p className=" bg-blueish font-semibold text-xs md:text-sm py-[2px] px-2 rounded-full w-fit h-fit shrink-0 /whitespace-nowrap">
                     {getTimeDifference(disclosed_date)}
                  </p>

                  {dateTime && (
                     <p className=" hidden xs:flex flex-wrap gap-2 text-sm w-fit">
                        <span className=" text-white/50 underline underline-offset-2">
                           Disclosed on:
                        </span>
                        <span className="italic">
                           {link ? (
                              <a
                                 href={`${link}`}
                                 target="_blank"
                                 className="hover:underline underline-offset-2"
                              >
                                 {dateTime.date}
                              </a>
                           ) : (
                              dateTime.date
                           )}
                        </span>
                        <span className="ml-1 italic">{dateTime.time}</span>
                     </p>
                  )}
               </header>
               {/* ==================== TRANSACTIONAL DATA ==================== */}
               <div className=" grid md:grid-cols-[55%,45%] lg:grid-cols-[60%,40%] text-[15px]">
                  <article className=" grid gap-2 lg:gap-4 lg:grid-cols-[55%,45%] shrink-0">
                     <div className=" grid gap-1">
                        {/* ===== ceo name and ticker ===== */}
                        <p className=" text-white/80 capitalize">
                           {company_name.toLowerCase()}
                        </p>
                        <div className=" flex w-full gap-2 text-lg font-bold sm:flex-nowrap /whitespace-nowrap">
                           <p className="text-blueish uppercase">{ticker}</p>
                           <p className=" capitalize">
                              {ceo_name.toLowerCase()}
                           </p>
                        </div>{" "}
                        {/* ===== total_amount_spent share_price total_shares ===== */}
                        <p className=" flex flex-wrap  gap-1 ">
                           {transaction_type.toUpperCase() === "P" ? (
                              <span className=" text-white/50">Bought </span>
                           ) : (
                              <span className=" text-white/50">Sold </span>
                           )}
                           <span>{totalShares?.toLocaleString()} </span>
                           <span className=" text-white/50">shares x</span>
                           <span>${sharePrice}</span>
                           <span className=" text-white/50">=</span>
                           <span>${TotalAmoutSpent?.toLocaleString()}</span>
                        </p>
                     </div>
                     {/* ===== share count ===== */}
                     <div className=" flex flex-wrap gap-[2px] lg:gap-2 w-full h-fit">
                        <p className=" text-white/50 md:w-full uppercase">
                           Share count:{" "}
                        </p>
                        <p className="">
                           {total_shares_after_transaction.toLocaleString()}{" "}
                           shares
                           <span className=" ml-1 text-prominenttext">
                              {"("}
                              {transaction_type.toUpperCase() === "P"
                                 ? "+"
                                 : "-"}
                              {changeInSharesPercentage}%{")"}
                           </span>
                        </p>
                     </div>
                  </article>
                  {/* ==================== RETURNS ==================== */}
                  {transaction_type.toUpperCase() === "P" && (
                     <aside className="  grid xs:grid-cols-3 justify-start mt-4 md:mt-0 gap-[2px] sm:gap-4 w-full h-fit text-base ">
                        {/* ===== 1 Week return ===== */}
                        <div className=" flex flex-wrap gap-2">
                           <p className=" text-white/50 xs:text-center xs:w-full uppercase">
                              1w return:
                           </p>
                           <p
                              className={clsx(
                                 "xs:w-full xs:text-center",
                                 weekReturn !== "--" &&
                                    (weekReturn.startsWith("+")
                                       ? "text-blue-500"
                                       : "text-red-500")
                              )}
                           >
                              {weekReturn}
                           </p>
                        </div>
                        {/* ===== 1 Month return ===== */}
                        <div className=" flex xs:justify-center flex-wrap gap-2">
                           <p className=" text-white/50 xs:text-center xs:w-full uppercase">
                              1m return:
                           </p>

                           <p
                              className={clsx(
                                 "xs:w-full xs:text-center",
                                 monthReturn !== "--" &&
                                    (monthReturn.startsWith("+")
                                       ? "text-blue-500"
                                       : "text-red-500")
                              )}
                           >
                              {monthReturn}
                           </p>
                        </div>
                        {/* ===== 1 Week return ===== */}
                        <div className=" flex xs:justify-center flex-wrap gap-2">
                           <p className=" text-white/50 xs:text-center xs:w-full uppercase">
                              6M return:
                           </p>
                           <p
                              className={clsx(
                                 "xs:w-full xs:text-center",
                                 halfReturn !== "--" &&
                                    (halfReturn.startsWith("+")
                                       ? "text-blue-500"
                                       : "text-red-500")
                              )}
                           >
                              {halfReturn}
                           </p>
                        </div>
                     </aside>
                  )}
                  {dateTime && (
                     <p className=" mt-4 grid justify-end xs:hidden text-sm w-full">
                        {" "}
                        <span className=" text-white/50">Disclosed on: </span>
                        <span className=" italic">
                           {" "}
                           {link ? (
                              <a
                                 href={`${link}`}
                                 target="_blank"
                                 className="hover:underline underline-offset-2"
                              >
                                 {dateTime.date}
                              </a>
                           ) : (
                              dateTime.date
                           )}
                        </span>
                        <span className="italic">{dateTime.time}</span>
                     </p>
                  )}
               </div>
            </div>
         )
      })}
   </section>
)
