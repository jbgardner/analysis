import { RadioGroup } from "@headlessui/react"
import { useState } from "react"
import { LockedI } from "../../../assets/Icons/Icons"

export function MarketCap({
   name,
   defaultValue,
   disabled,
}: {
   name: string
   defaultValue: number | undefined
   disabled?: boolean
}) {
   const [selected, setSelected] = useState(defaultValue ? defaultValue : 0)

   const handleSelect = (val: number) => {
      if (val === selected) setSelected(0)
      else setSelected(val)
   }

   return (
      <RadioGroup
         value={selected}
         name={name}
         disabled={disabled}
         onChange={(val) => handleSelect(val)}
         className="filters-container "
      >
         <RadioGroup.Label className="filters-label  ">
            Market Capital:{" "}
            {disabled && (
               <span className=" xs:hidden font-normal text-prominenttext ">
                  Pro
               </span>
            )}
         </RadioGroup.Label>
         <div className=" w-full flex gap-1 xs:gap-2 items-center justify-start">
            <RadioGroup.Option
               onClick={() => handleSelect(1)}
               className=" maket-cap-button-container"
               value={1}
            >
               {({ checked }) => (
                  <span className={checked ? "text-blueish" : ""}>Micro</span>
               )}
            </RadioGroup.Option>
            <RadioGroup.Option
               onClick={() => handleSelect(2)}
               className="maket-cap-button-container"
               value={2}
            >
               {({ checked }) => (
                  <span className={checked ? "text-blueish" : ""}>Small</span>
               )}
            </RadioGroup.Option>
            <RadioGroup.Option
               onClick={() => handleSelect(3)}
               className="maket-cap-button-container"
               value={3}
            >
               {({ checked }) => (
                  <span className={checked ? "text-blueish" : ""}>Mid</span>
               )}
            </RadioGroup.Option>
            <RadioGroup.Option
               onClick={() => handleSelect(3)}
               className="maket-cap-button-container"
               value={4}
            >
               {({ checked }) => (
                  <span className={checked ? "text-blueish" : ""}>Large</span>
               )}
            </RadioGroup.Option>
            <div className=" xs:pl-[47px]">
               {disabled && (
                  <span className="grid justify-end w-full pro-psudo-text">
                     <LockedI className="  h-4 w-4  " />
                  </span>
               )}
            </div>
         </div>
      </RadioGroup>
   )
}
