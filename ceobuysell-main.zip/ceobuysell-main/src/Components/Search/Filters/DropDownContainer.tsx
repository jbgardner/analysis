import { Fragment, useState } from "react"
import { Listbox, Transition } from "@headlessui/react"
import { Check, GoforwardSingleI, LockedI } from "../../../assets/Icons/Icons"
import clsx from "clsx"

export const DropDownContainer = ({
   name,
   mapingArray,
   defaultValue,
   disabled,
}: {
   defaultValue: number
   name: string
   mapingArray: any[]
   disabled?: boolean
}) => {
   const [selectedValue, setSelected] = useState(defaultValue)

   const handleSelected = (val: any) => {
      setSelected(val)
   }

   return (
      <Listbox
         name={name}
         disabled={disabled}
         value={selectedValue}
         onChange={handleSelected}
      >
         <div className="relative mt-1 w-full grid text-left">
            <Listbox.Button className=" w-full cursor-pointer bg-inputColor rounded-lg  py-2 pl-3 pr-10 text-left shadow-md text-sm sm:text-base ui-focus-visible:bg-blueish disabled:text-white/50 disabled:shadow-none disabled:bg-inputColor/20 disabled:cursor-not-allowed">
               {({ open }) => (
                  <>
                     <span className="block truncate">
                        {mapingArray[selectedValue]}
                     </span>
                     <span className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2 ">
                        {disabled ? (
                           <span className=" pro-psudo-text">
                              <LockedI className="  h-4 w-4 fill-prominenttext " />
                           </span>
                        ) : (
                           <GoforwardSingleI
                              className={clsx(
                                 " h-4 w-4 transition-transform duration-150 ease-in-out ",
                                 open ? " rotate-90" : "rotate-0"
                              )}
                           />
                        )}
                     </span>
                  </>
               )}
            </Listbox.Button>
            <Transition
               as={Fragment}
               enter="ease-out duration-200"
               enterFrom="opacity-0 -translate-y-14 scale-y-50"
               enterTo="opacity-100 scale-y-100"
               leave="ease-in duration-100"
               leaveFrom="opacity-100 translate-y-14 scale-y-100"
               leaveTo="opacity-0 scale-y-90"
            >
               <Listbox.Options className="absolute top-11 max-h-60 w-full overflow-auto rounded-md bg-inputColor text-base shadow-lg shadow-black/40 ring-1 ring-black/5 focus:outline-none sm:text-sm z-10">
                  {mapingArray.map((item, index) => (
                     <Listbox.Option
                        key={index}
                        className={({ active }) =>
                           `relative cursor-default select-none py-2 pl-10 px-2 ${
                              active ? " bg-blueish text-white" : "text-white "
                           } 
                              ${index == 0 && name == "sort" && "hidden"}
                              `
                        }
                        value={index}
                     >
                        <span
                           className={`block ${
                              selectedValue === index
                                 ? "font-medium"
                                 : "font-normal"
                           }`}
                        >
                           {item}
                        </span>
                        {selectedValue === index ? (
                           <span className="absolute inset-y-0 left-0 flex items-center pl-3 ">
                              <Check
                                 className="h-5 w-5 stroke-prominenttext"
                                 aria-hidden="true"
                              />
                           </span>
                        ) : null}
                     </Listbox.Option>
                  ))}
               </Listbox.Options>
            </Transition>
         </div>
      </Listbox>
   )
}
