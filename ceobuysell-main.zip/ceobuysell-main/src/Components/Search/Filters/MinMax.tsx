import { useState } from "react"
import { LockedI } from "../../../assets/Icons/Icons"

export function MinMax({
   defaultMin,
   defaultMax,
   name,
   label,
   disabled,
}: {
   defaultMin: number | undefined
   defaultMax: number | undefined
   name: string
   label: string
   disabled?: boolean
}) {
   const [minValue, setMinValue] = useState(0)
   let add: string = ""
   switch (name) {
      case "share_price":
      case "total_amount":
         add = " $"
         break
      case "ownership_increase":
         add = " %"
   }

   const placeHolderMin = "Min" + add
   const placeHolderMax = "Max" + add

   const min = name + "_min"
   const max = name + "_max"
   return (
      <div className="filters-container">
         <p className="filters-label ">
            {label}:
            {disabled && (
               <span className=" xs:hidden font-normal text-prominenttext ">
                  Pro
               </span>
            )}
         </p>
         <div
            className={` max-w-full grid ${
               disabled
                  ? "grid  grid-cols-[6rem,2rem,6rem,1.5rem] xs:grid-cols-[7rem,2rem,7rem,4rem]"
                  : "  grid-cols-[6rem,2rem,6rem] xs:grid-cols-[7rem,2rem,7rem] "
            } items-center gap-1 `}
         >
            <input
               className="outline-none px-2 py-1 rounded-md bg-inputColor disabled:brightness-75 disabled:bg-inputColor/20 disabled:cursor-not-allowed"
               id="outlined-number"
               name={min}
               placeholder={placeHolderMin}
               type="number"
               onChange={(e) => {
                  setMinValue(parseInt(e.target.value))
               }}
               disabled={disabled}
               defaultValue={defaultMin}
               min={0}
               max={name === "ownership_increase" ? 100 : undefined}
            />
            <p>and</p>
            <input
               className="outline-none px-2 py-1 rounded-md bg-inputColor disabled:brightness-75 disabled:bg-inputColor/20 disabled:cursor-not-allowed"
               id="outlined-number"
               name={max}
               disabled={disabled}
               placeholder={placeHolderMax}
               type="number"
               defaultValue={defaultMax}
               max={name === "ownership_increase" ? 100 : undefined}
               min={defaultMin ? defaultMin : minValue}
            />
            {disabled && (
               <span className=" grid w-full justify-end pro-psudo-text">
                  <LockedI className="  h-4 w-4 fill-prominenttext " />
               </span>
            )}
         </div>
      </div>
   )
}
