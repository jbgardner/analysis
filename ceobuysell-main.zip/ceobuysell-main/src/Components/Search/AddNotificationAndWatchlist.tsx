import { FC, useState } from "react"
import { UserT, searchDataT } from "../../utils/interfaces&Types"
import { useAuth } from "../../Hooks/useAuth"
import supabase from "../../Services/auth.service"
import toast from "react-hot-toast"
import { Checkbox } from "@mui/material"
import { filtersExistsInCustomNotifications } from "../../utils/Helper"
import { PlusI } from "../../assets/Icons/Icons"

export const AddNotificationAndWatchlist: FC<{
   hasSpecificFilters: boolean
   user: UserT
   filters: searchDataT
   setUser: (arg: UserT) => void
   watchlistFilteredTickers: string[] | null
}> = ({
   hasSpecificFilters,
   watchlistFilteredTickers,
   user,
   setUser,
   filters,
}) => {
   const {
      setModelIndex,
      setOpenModel,
      customNotifications,
      fetchCustomNotifications,
   } = useAuth()

   const [notification, setNotification] = useState<{
      email_notification: boolean
      text_notification: boolean
   }>({ email_notification: true, text_notification: false })

   const handleAddNumber = () => {
      setOpenModel(true)
      setModelIndex(2)
   }

   // Insert watchlist items into the database and update user state
   const insertWatchlist = async () => {
      if (user && watchlistFilteredTickers) {
         for (let index = 0; index < watchlistFilteredTickers.length; index++) {
            const { error } = await supabase.from("watchlist").insert({
               user_id: user.user_id,
               name: watchlistFilteredTickers[index],
            })

            if (error) throw new Error(error.message)
         }

         const watchlist = watchlistFilteredTickers.concat(
            user.watchlist ? user.watchlist : []
         )
         setUser({ ...user, watchlist })
      }
   }

   // Handle adding watchlist with toast notification
   const handleAddWatchlist = () => {
      toast.promise(
         insertWatchlist(),
         {
            loading: "Adding...",
            success: "Successfully added",
            error: (error) =>
               error.message || "Something went wrong Please try again later",
         },
         { position: "bottom-right", duration: 2000 }
      )
   }

   // Insert watchlist items into the database and update user state
   const insertCustomNotification = async () => {
      if (user) {
         const { error } = await supabase.from("custom_notifications").insert({
            ticker: filters.ticker,
            q: filters.q,
            sector: filters.sector,
            market_cap: filters.market_cap,
            share_count_min: filters.share_count_min,
            share_count_max: filters.share_count_max,
            share_price_min: filters.share_price_min,
            share_price_max: filters.share_price_max,
            total_amount_min: filters.total_amount_min,
            total_amount_max: filters.total_amount_max,
            total_share_owned_min: filters.total_share_owned_min,
            total_share_owned_max: filters.total_share_owned_max,
            ownership_increase_min: filters.ownership_increase_min,
            ownership_increase_max: filters.ownership_increase_max,
            total_share_min: filters.total_share_min,
            total_share_max: filters.total_share_max,
            transaction_type: filters.transaction_type,
            user_id: user.user_id,
            settings: notification,
         })
         // .eq("user_id", user.user_id)

         if (error) throw new Error(error.message)

         await fetchCustomNotifications(user.user_id)
      }
   }

   // Handle adding custom notification
   const handleAddCustomNotification = () => {
      // console.log(
      //    filtersExistsInCustomNotifications(filters, customNotifications)
      // )
      // return
      toast.promise(
         insertCustomNotification(),
         {
            loading: "Adding...",
            success: "Successfully added",
            error: (error) =>
               error.message || "Something went wrong Please try again later",
         },
         { position: "bottom-right", duration: 4000 }
      )
   }

   if (
      hasSpecificFilters &&
      !filtersExistsInCustomNotifications(filters, customNotifications)
   )
      return (
         <section className=" grid justify-center mx-auto w-fit bg-darkfg shadow-lg md:shadow-black p-3 lg:p-4 rounded-lg h-fit mb-2 md:-mb-2 lg:-mb-6 ">
            <div className=" flex flex-wrap items-end gap-1 md:gap-8 relative ">
               <div className="">
                  <p className=" text-lg">
                     Add this search to your notification
                  </p>
                  <div className="flex flex-wrap gap-x-3 md:gap-4">
                     <div className=" whitespace-nowrap flex items-center gap-1 flex-nowrap">
                        <Checkbox
                           checked={notification.email_notification}
                           onChange={() =>
                              setNotification({
                                 ...notification,
                                 email_notification:
                                    !notification.email_notification,
                              })
                           }
                           inputProps={{ "aria-label": "controlled" }}
                           sx={{ ml: "-8px" }}
                        />
                        <p className=" text-[rgb(198,198,198)] ">Email</p>
                     </div>

                     <div className="whitespace-nowrap flex flex-nowrap items-center gap-1">
                        <Checkbox
                           checked={notification.text_notification}
                           onChange={() =>
                              setNotification({
                                 ...notification,
                                 text_notification:
                                    !notification.text_notification,
                              })
                           }
                           inputProps={{
                              "aria-label": "controlled",
                           }}
                           disabled={!user.phone}
                           sx={{ ml: "-8px" }}
                        />
                        <p className=" text-[rgb(198,198,198)] ">Text</p>
                        {!user.phone && (
                           <p
                              className=" ml-2 underline text-blueish cursor-pointer"
                              onClick={handleAddNumber}
                           >
                              Add phone number
                           </p>
                        )}
                     </div>
                  </div>
               </div>
               <div className="grid w-full md:w-fit justify-end">
                  <button
                     onClick={handleAddCustomNotification}
                     className="w-fit h-fit grid border border-blueish transition-all duration-[0.2s] hover:bg-blueish p-[6px] rounded-xl"
                  >
                     <PlusI className=" h-6 w-6 stroke-white" />
                  </button>
               </div>
            </div>
         </section>
      )

   if (watchlistFilteredTickers !== null && !hasSpecificFilters)
      return (
         <section className=" grid justify-center w-full h-full mb-2 md:-mb-2 lg:-mb-6 ">
            <div className=" flex flex-wrap justify-center items-center gap-1 md:gap-3 relative bg-darkfg shadow-lg md:shadow-black p-3 lg:p-4 rounded-lg h-fit w-full">
               <p className=" text-lg text-center">
                  Add
                  <span className=" mx-2 font-extrabold text-blueish">
                     {watchlistFilteredTickers
                        .toLocaleString()
                        .replace(/,/g, ", ")}
                  </span>
                  to your watchlist
               </p>
               <button
                  onClick={handleAddWatchlist}
                  className="w-fit grid items-center justify-center border border-blueish transition-all duration-[0.2s] hover:bg-blueish p-[6px] rounded-xl"
               >
                  <PlusI className=" h-6 w-6 stroke-white" />
               </button>
            </div>
         </section>
      )
}
