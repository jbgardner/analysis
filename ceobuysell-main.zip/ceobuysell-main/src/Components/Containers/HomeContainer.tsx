// import { Highlighter } from "../../assets/Icons/Icons"
import { useScroll, useTransform, motion } from "framer-motion"
import backgroundImg from "../../assets/Images/backgroundImg.webp"
import highlight from "../../assets/Images/highlighter.webp"
import "../../Styles/homeContainer.css"

export const HomeContainer = ({ children }: { children: JSX.Element }) => {
   const { scrollYProgress } = useScroll()
   const y = useTransform(scrollYProgress, [0, 1], ["-10%", "0%"])
   const y1 = useTransform(scrollYProgress, [0, 1], ["10%", "35%"])

   return (
      <div className="w-full mx-auto max-w-[1800px] h-full bg-darkbg text-white relative home-Container-Image">
         <motion.div
            className=" fixed max-w-[1800px] hidden md:flex justify-center h-full w-full inset-0 mx-auto "
            style={{
               y: y1,
               backgroundImage: `url(${highlight})`,
               backgroundSize: "130% 130%",
               backgroundPosition: "center",
            }}
         ></motion.div>
         <motion.div
            className="hidden md:grid fixed max-w-[1800px] h-[200vh] w-full "
            style={{
               y,
               backgroundImage: `url(${backgroundImg})`,
               objectFit: "cover",
               backgroundPosition: "center",
               backgroundRepeat: "repeat",
            }}
         ></motion.div>
         {children}
      </div>
   )
}
