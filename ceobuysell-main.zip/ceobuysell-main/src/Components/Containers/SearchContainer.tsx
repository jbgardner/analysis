import { Footer } from "../Header&fFooter/Footer"
import { SearchHeader } from "../Header&fFooter/SearchHeader"
import { Outlet } from "react-router-dom"

import highlight from "../../assets/Images/highlighter.webp"
import { useScroll, useTransform, motion } from "framer-motion"
import { useEffect, useRef, useState } from "react"
import { useAuth } from "../../Hooks/useAuth"

export function SearchContainer() {
   const mainRf = useRef<HTMLDivElement>(null)
   const { scrollYProgress } = useScroll({ target: mainRf })
   const y = useTransform(scrollYProgress, [0, 1], ["0%", "30%"])
   const [height, setHeight] = useState<null | number>(null)
   const [fetching, setFetching] = useState<boolean>(false)

   const { fetchCustomNotifications, user, customNotifications } = useAuth()

   const callfetch = async (id: string) => {
      setFetching(true)
      await fetchCustomNotifications(id)
      setFetching(false)
   }

   useEffect(() => {
      if (user?.user_id && customNotifications === null) callfetch(user.user_id)
   }, [user])

   const getDivHeight = () => {
      if (mainRf.current) {
         const height = mainRf.current.offsetHeight

         return height
      } else return null
   }

   useEffect(() => {
      setHeight(getDivHeight())
   }, [])

   return (
      <div
         className="mx-auto max-w-[1800px] w-full h-full bg-darkbg text-white relative z-0 "
         ref={mainRf}
      >
         <div className=" w-full h-full ">
            <SearchHeader />
            <main className=" max-w-maximum mx-auto bg-darkbg/40 h-full p-[1rem] md:py-[3rem] lg:px-[4rem] xl:px-[5rem] relative">
               <Outlet context={{ fetching }} />
            </main>
            <Footer />
            <motion.div
               className=" fixed max-w-[1800px] hidden md:flex justify-center h-full w-full inset-0 mx-auto -z-10"
               style={{
                  y: y,
                  backgroundImage: `url(${highlight})`,
                  backgroundSize: "120% 120%",
                  backgroundPosition: "center",
                  maxHeight: `${height}px`,
               }}
            ></motion.div>
         </div>
      </div>
   )
}
