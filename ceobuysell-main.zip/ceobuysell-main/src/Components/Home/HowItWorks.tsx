import { howitworks } from "../../utils/Constants"
import { GoforwardI } from "../../assets/Icons/Icons"

import highlight from "../../assets/Images/highlighter.webp"
import { motion } from "framer-motion"
import { FC } from "react"
import { useMediaQuery } from "@mui/material"

export const HowItWorks: FC = () => {
   const widthy = useMediaQuery("(max-width:500px)")

   return (
      <section
         id="howitworks"
         className="w-full h-auto bg-darkbg relative overflow-clip bg-[center] bg-[length:120%] md:bg-[length:100%] lg:bg-[length:100%]"
         style={{
            backgroundImage: `url(${highlight})`,
            backgroundRepeat: "no-repeat",
         }}
      >
         <div className=" max-w-maximum mx-auto pt-20 pb-20 xs:pb-[10rem] bg-darkbg/20">
            <h2 className="px-5 md:px-0 text-center font-bold text-title2 sm:text-title1">
               {howitworks.title}
            </h2>
            <p className=" mx-auto my-6  min-w-[220px] px-2 md:px-0 w-[85%] sm:w-[60%] md:text-lg lg:text-lg text-center">
               {howitworks.para}
            </p>
            <div className=" w-full flex  justify-center flex-wrap gap-12 mt-9 px-2">
               {howitworks.cards.map((item, index) => (
                  <motion.div
                     initial={{
                        opacity: widthy ? 1 : 0,
                        x: widthy ? 0 : 20,
                     }}
                     whileInView={{ opacity: 1, x: 0 }}
                     transition={{ duration: 0.3, delay: index * 0.1 }}
                     key={index}
                     className=" relative"
                  >
                     <div className=" h-[14rem] w-[14rem] border-grad-rotate-bg2 before:w-[150%] before:h-[150%] before:-left-[3.5rem]">
                        {/* card Items */}
                        <div className=" card_backgroud w-full h-full rounded-xl p-3 grid justify-center ">
                           <div className=" mx-auto mt-2 p-5 h-6 w-6 relative bg-white/10 rounded-full">
                              <img
                                 src={item.imageUrl}
                                 className=" absolute inset-0 m-auto "
                                 alt=""
                              />
                           </div>
                           <h2 className="mx-auto text-center font-bold mt-4 mb-3">
                              {item.title}
                           </h2>
                           <p className="mx-auto text-center text-sm pb-5">
                              {item.para}
                           </p>
                        </div>
                     </div>
                     {/* arrow */}
                     {index != 0 && (
                        <div className=" hidden absolute md:grid items-center inset-0 -left-[2.3rem]">
                           <GoforwardI className="h-7 w-7 bg-blueish rounded-full p-2 stroke-white fill-white " />
                        </div>
                     )}
                  </motion.div>
               ))}
            </div>
         </div>
      </section>
   )
}
