import clsx from "clsx"
import { feature } from "../../utils/Constants"
import { FC } from "react"
import { motion } from "framer-motion"

export const Features: FC = () => {
   return (
      <section
         id="features"
         className="w-full h-full relative overflow-clip bg-darkbg/20 "
      >
         <div className=" max-w-maximum mx-auto  ">
            <div className=" grid  justify-center  grid-cols-1 lg:grid-cols-[50%,1fr] py-20 lg:pt-[7rem] gap-10 mx-3 xs:mx-6 md:mx-11  xl:mx-20">
               <motion.article className="  grid h-fit justify-center sticky top-20 ">
                  <h2
                     className={clsx(
                        "px-5 md:px-0 text-left font-bold text-title2 sm:text-title1 mb-[5vh] "
                     )}
                  >
                     {feature.title}
                  </h2>

                  <ul className="space-y-[1.5rem] lg:space-y-[2vh]">
                     {feature.featureCards.map((cardData, index) => (
                        <motion.div
                           key={index}
                           initial={{
                              opacity: 0,
                              y: 30,
                           }}
                           whileInView={{ opacity: 1, y: 0 }}
                           viewport={{ once: true }}
                           transition={{ duration: 0.5, delay: index * 0.1 }}
                           className="w-fit"
                        >
                           <div className="p-4 rounded-xl space-y-[1vh] bg-featurebg border border-white/20">
                              <h3 className="text-lg md:text-xl font-bold md:font-extrabold ">
                                 {cardData.title}
                              </h3>
                              <p className="text-sm md:text-base max-w-[30rem] lg:max-w-none">
                                 {" "}
                                 {cardData.para}
                              </p>
                              <figure className="grid lg:hidden justify-center mt-5">
                                 <img
                                    className=" w-full h-full"
                                    src={feature.featursImage[index]}
                                    alt={cardData.title}
                                 />
                              </figure>
                           </div>
                        </motion.div>
                     ))}
                  </ul>
               </motion.article>
               <aside className=" w-fit h-full  hidden lg:block relative  ">
                  <div className="  grid w-fit h-fit justify-center gap-5 bg-featurebg rounded-xl p-4 ">
                     {feature.featursImage.map((image, index) => (
                        <div key={index} className="w-fit">
                           <img
                              src={image}
                              className=" w-full h-full"
                              alt={feature.featureCards[index].title}
                           />
                        </div>
                     ))}
                  </div>
               </aside>
            </div>
         </div>
      </section>
   )
}
