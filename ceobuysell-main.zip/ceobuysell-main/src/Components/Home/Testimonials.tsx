import { FC } from "react"
import { testimonials } from "../../utils/Constants"

export const Testimonials = () => {
   return (
      <section
         id="testimonials"
         className="w-full h-auto bg-darkbg/40 .bg-[#090b20c2]  relative overflow-clip"
      >
         <div className=" max-w-maximum mx-auto pt-20 pb-[6rem] px-6 md:px-4">
            <h2 className="px-5 md:px-0 text-center font-bold text-title2 sm:text-title1">
               {testimonials.title}
            </h2>
            <div className="  w-full flex  justify-center flex-wrap gap-4 mt-8 mx-auto text-white/80 ">
               {testimonials.cards.slice(0, 3).map((testimonial, index) => (
                  <div
                     className=" w-full h-auto md:w-[47%] lg:w-[30.9%] relative  p-[2px] rounded-xl "
                     key={index}
                  >
                     <TestimonialCard testimonial={testimonial} />
                  </div>
               ))}
            </div>
            <div className=" grid justify-center grid-cols-1 md:grid-cols-[47%,47%] gap-4 mt-4 mx-auto  text-white/80">
               {testimonials.cards.slice(3, 5).map((testimonial, index) => (
                  <div
                     className="w-full h-auto relative  p-[2px] rounded-xl "
                     key={index}
                  >
                     <TestimonialCard testimonial={testimonial} />
                  </div>
               ))}
            </div>
         </div>
      </section>
   )
}

const TestimonialCard: FC<{
   testimonial: {
      image: string
      author: string
      jobTitle: string
      para: string
   }
}> = ({ testimonial }) => (
   <div className=" p-4 shadow shadow-blueish mx-auto max-w-[30rem] md:max-w-none transition-all duration-300 ease-in-out rounded-xl bg-grad_lightBlue w-full h-full">
      <p>
         <span className="font-bold">“</span>
         {testimonial.para}
         <span className="font-bold">”</span>
      </p>
      <div className=" flex gap-4 mt-4">
         <img
            className=" w-[3.2rem] h-[3.2rem]"
            src={testimonial.image}
            alt={testimonial.author}
         />
         <div className=" leading-3 ">
            <span className="font-extrabold text-base md:text-lg">
               {testimonial.author}
            </span>
            <br />
            <span className="text-sm ">{testimonial.jobTitle}</span>
         </div>
      </div>
   </div>
)
