import { stories } from "../../utils/Constants"

export const Stories = () => (
   <section
      id="stories"
      className="w-full h-auto card_backgroud  relative overflow-clip"
   >
      <div className=" max-w-maximum px-4 lg:px-8 mx-auto py-[7rem]">
         {/* title */}
         <h2 className="px-5 md:px-0 text-center font-bold text-title2 sm:text-title1">
            {stories.title}
         </h2>
         {/* para */}
         <p className=" mx-auto my-6  min-w-[220px] px-2 md:px-0 w-[95%] xs:w-[80%] sm:w-[75%] md:text-lg lg:text-lg text-center">
            {stories.para}
         </p>
         <div className=" w-full flex justify-center flex-wrap gap-6 md:gap-8  mt-10 ">
            {/* card */}
            {stories.stories.map((card, index) => (
               <div
                  key={index}
                  className="h-full w-fit transition-all ease-in-out duration-[0.4s] rounded-xl p-[1px] shadow-lg shadow-black bg-gradient-to-br from-white/20 to-white/5 hover:scale-105"
               >
                  <div className="mx-auto w-fit h-full rounded-xl p-4 sm:p-5 grid gap-2 md:gap-4 items-end xs:grid-cols-[14rem,1fr] sm:grid-cols-[18rem,1fr] bg-gradient-to-tr from-darkblue to-[#12142C]">
                     <div className=" w-full">
                        {/* card title */}
                        <h2 className=" md:text-lg font-bold ">{card.title}</h2>
                        {/* card para */}
                        <div className=" mt-4">
                           {card.para.map((para, i) => (
                              <span
                                 key={i}
                                 className={
                                    i % 2 === 0
                                       ? "text-white/80"
                                       : " text-white font-semibold"
                                 }
                              >
                                 {para}
                              </span>
                           ))}
                        </div>
                     </div>
                     {/* card image */}
                     <div className=" h-fit w-fit ml-auto ">
                        <img
                           src={card.imgeUrl}
                           className=" object-contain  origin-bottom"
                           alt=""
                        />
                     </div>
                  </div>
               </div>
            ))}
         </div>
      </div>
   </section>
)
