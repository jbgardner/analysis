import { SearchBar } from "../Common/SearchBar"
import { hero } from "../../utils/Constants"

export const Hero = () => {
   return (
      <section className=" max-w-maximum mx-auto flex flex-wrap justify-center relative">
         <div className=" w-full mt-20 ">
            <h1 className=" px-5 md:px-0 text-center font-bold text-2xl  sm:text-title1 md:text-title ">
               {hero.title[0]}
               <br />
               {hero.title[1]}
            </h1>
         </div>

         <div className=" mt-10 mb-5 min-w-[17rem] px-2 md:px-0 w-[60%] md:text-lg lg:text-lg text-center">
            <span className=" text-white/80">{hero.para0[0]}</span>
            <span className=" font-bold">{hero.para0[1]}</span>
            <span className="text-white/80 ">{hero.para0[2]}</span>
            <span className=" font-bold">{hero.para0[3]}</span>
         </div>

         <div className="w-full">
            <SearchBar className="my-4 mx-auto min-w-[17rem] w-[65%] focus-within:scale-105 rounded-[23.8px]" />
         </div>
         <div className="w-full grid justify-center px-2 md:px-0">
            <h2 className="w-fit mt-5 text-center sm:text-xl border-b border-blueish pb-2 text-yellowish">
               {hero.para1}
            </h2>
         </div>

         <div className=" w-full px-10 sm:px-10 md:px-0 mt-10">
            <img src={hero.imageUrl} alt="" className="mx-auto" />
         </div>
      </section>
   )
}

// import { SearchBar } from "../Common/SearchBar"
// import { hero } from "../../utils/Constants"
// import { useScroll, motion, useTransform } from "framer-motion"
// import { useRef } from "react"

// export const Hero = () => {
//    const iphoneRef = useRef(null)
//    const { scrollYProgress } = useScroll({
//       target: iphoneRef,
//       // offset: ["center end", "start start"],
//    })
//    const y = useTransform(scrollYProgress, [0, 1], ["0%", "10%"])

//    return (
//       <section className=" max-w-maximum mx-auto flex flex-wrap justify-center relative">
//          <div className=" w-full mt-20 ">
//             <h1 className=" px-5 md:px-0 text-center font-bold text-2xl  sm:text-title1 md:text-title ">
//                {hero.title[0]}
//                <br />
//                {hero.title[1]}
//             </h1>
//          </div>

//          <div className=" mt-10 mb-5 min-w-[17rem] px-2 md:px-0 w-[60%] md:text-lg lg:text-lg text-center">
//             <span className=" text-white/80">{hero.para0[0]}</span>
//             <span className=" font-bold">{hero.para0[1]}</span>
//             <span className="text-white/80 ">{hero.para0[2]}</span>
//             <span className=" font-bold">{hero.para0[3]}</span>
//          </div>

//          <div className="w-full">
//             <SearchBar className="my-4 mx-auto min-w-[17rem] w-[65%] focus-within:scale-105 rounded-[23.8px] " />
//          </div>
//          <div className="w-full grid justify-center px-2 md:px-0">
//             <h2 className="w-fit mt-5 text-center sm:text-xl border-b border-blueish pb-2 text-yellowish">
//                {hero.para1}
//             </h2>
//          </div>

//          <motion.div
//             ref={iphoneRef}
//             className=" w-full px-10 sm:px-10 md:px-0"
//             style={{ y }}
//          >
//             <img src={hero.imageUrl} alt="" className="mx-auto" />
//          </motion.div>
//       </section>
//    )
// }
