import { FC, ReactNode, useEffect, useState } from "react"
import { getAllPosts } from "../../Services/blog.services"
import { PostOrPage } from "tryghost__content-api"
import Loader from "../Common/Loader"
import "react-responsive-carousel/lib/styles/carousel.min.css" // requires a loader
import { Carousel } from "react-responsive-carousel"
import { Goback } from "../../assets/Icons/Icons"
import clsx from "clsx"
import { useNavigate } from "react-router-dom"

export const Blogs = () => {
   const [blogs, setBlogs] = useState<PostOrPage[] | null>(null)
   const [loading, setLoading] = useState(true)
   const navigate = useNavigate()

   useEffect(() => {
      setLoading(true)
      getAllPosts().then((data: PostOrPage[]) => {
         if (data !== null) {
            setBlogs(data)
         }
         setLoading(false)
      })
   }, [])

   const handleReadMore = (slug: string) => {
      navigate(`/blog/${slug}`)
   }

   if (loading)
      return (
         <section
            id="blog"
            className="w-full h-auto bg-darkbg/40 relative overflow-clip"
         >
            <div className=" max-w-maximum mx-auto sm:pt-12 sm:pb-[10rem] ">
               <h2 className="px-5 md:px-0 text-center font-bold text-title2 sm:text-title1">
                  Our Blog
               </h2>
               <div className=" h-[30rem]">
                  <Loader size={30} />
               </div>
            </div>
         </section>
      )

   if (!blogs)
      return (
         <section
            id="blog"
            className="w-full h-auto bg-darkbg/40 relative overflow-clip"
         >
            <div className=" max-w-maximum mx-auto sm:pt-12 sm:pb-[10rem] ">
               <h2 className="px-5 md:px-0 text-center font-bold text-title2 sm:text-title1">
                  Our Blog
               </h2>
               <div className=" h-[30rem]">
                  <div className=" h-full p-[2px] rounded-xl  mt-10 border-grad-rotate-bg before:w-[60%] before:h-[200%] w-[90%] sm:w-[75%] md:w-[40rem]  mx-auto ">
                     <div className="grid items-center justify-center h-full w-full rounded-xl  story_backgroud p-6">
                        <p className=" font-extrabold pt-3 text-center text-xl md:text-[1.35rem]">
                           Sory for inconvenience
                           <br />
                           The articles not currently available
                        </p>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      )

   return (
      <section
         id="blog"
         className="w-full h-auto bg-darkbg/40 relative overflow-clip"
      >
         <div className=" max-w-maximum mx-auto sm:pt-12 sm:pb-[10rem] ">
            <h2 className="px-5 md:px-0 text-center font-bold text-title2 sm:text-title1">
               Our Blog
            </h2>
            <Carousel
               showStatus={false}
               showIndicators={false}
               showThumbs={false}
               className=" relative mt-10"
               renderArrowPrev={(clickHandler, hasPrev) => (
                  <CarouselArrows
                     clickHandler={clickHandler}
                     className={clsx(
                        " left-3 sm:left-10 lg:left-[10%]",
                        !hasPrev && "hidden"
                     )}
                  >
                     <Goback className=" h-full " />
                  </CarouselArrows>
               )}
               renderArrowNext={(clickHandler, hasNext) => (
                  <CarouselArrows
                     clickHandler={clickHandler}
                     className={clsx(
                        " right-3 sm:right-10 lg:right-[10%]",
                        !hasNext && "hidden"
                     )}
                  >
                     <Goback className=" h-full rotate-180  " />
                  </CarouselArrows>
               )}
               useKeyboardArrows
               infiniteLoop
            >
               {blogs.map((blog: PostOrPage, index) => (
                  <article
                     key={index}
                     className=" border-grad-rotate-bg before:w-[60%] before:h-[160%] w-[90%] sm:w-[75%] md:w-[40rem] p-[2px] h-full  mx-auto  "
                  >
                     <div className=" h-full w-full rounded-xl p-4 grid justify-center story_backgroud ">
                        <div className=" mx-auto max-h-[23rem] overflow-clip rounded-xl object-cover object-center ">
                           {blog.feature_image && (
                              <img
                                 className="  w-full"
                                 src={blog.feature_image}
                              />
                           )}
                        </div>
                        <p className=" font-extrabold pt-3 text-left text-xl md:text-[1.35rem]">
                           {blog.title}
                        </p>
                        <p className=" text-left  pb-6 pt-2 leading-7 text-base text-white/80 ">
                           {blog.excerpt}
                        </p>
                        {/* Read more button */}
                        <button
                           className=" w-fit border border-blueish transition-all duration-[0.3s]  hover:bg-blueish hover:scale-105 px-3 py-2 rounded-md"
                           onClick={() => handleReadMore(blog.slug)}
                        >
                           Read More
                        </button>
                     </div>
                  </article>
               ))}
            </Carousel>
         </div>
      </section>
   )
}

type CarouselArrowsProps = {
   clickHandler: () => void
   children: ReactNode
   className: string
}

export const CarouselArrows: FC<CarouselArrowsProps> = ({
   clickHandler,
   children,
   className,
}) => {
   return (
      <button
         className={clsx(
            " absolute top-0 h-full grid items-center z-10 ",
            className
         )}
         onClick={clickHandler}
      >
         <span className=" bg-white hover:bg-blueish transition-all duration-200 rounded-full stroke-black fill-none h-8 md:h-10">
            {children}
         </span>
      </button>
   )
}
