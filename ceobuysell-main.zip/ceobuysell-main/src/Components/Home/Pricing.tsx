import clsx from "clsx"
import { pricing } from "../../utils/Constants"
import { Check } from "../../assets/Icons/Icons"
import { useRef } from "react"
import { useInView } from "framer-motion"
import { checkoutSession } from "../../Services/auth.service"
import { useAuth } from "../../Hooks/useAuth"
import { useNavigate } from "react-router-dom"
import toast from "react-hot-toast"
import "../../Styles/home.css"

export const Pricing = () => {
   const containerRef = useRef(null)
   const isAnimated = useInView(containerRef)
   const { user, setOpenModel, setModelIndex } = useAuth()
   const navigate = useNavigate()

   const handlePurchase = async (plan: string) => {
      try {
         const req = { user_id: "", plan }
         if (user) {
            if (!user.isPro && user.id) {
               req.user_id = user.id
               const res = await checkoutSession(req)
               window.location.href = res.data.session_url
            } else navigate("/dashboard")
         } else {
            setModelIndex(1)
            setOpenModel(true)
         }
      } catch (error) {
         // console.log("Error occured st Pricing line::30 ", error)
         toast.error(
            "Someting went wrong please try again or contact us at info@ceobuysell.com"
         )
      }
   }

   return (
      <section
         id="pricing"
         ref={containerRef}
         className="w-full h-auto bg-darkbg   relative overflow-clip"
      >
         <div className=" max-w-maximum mx-auto pt-[6rem] pb-[7.5rem]">
            <h2 className="px-5 md:px-0 text-center font-bold text-title2 sm:text-title1">
               {pricing.title}
            </h2>
            <div className=" w-full flex  justify-center flex-wrap gap-12 lg:gap-20 mt-14 ">
               {pricing.plans.map((card, index) => (
                  <div
                     key={index}
                     className={clsx(
                        "border-grad-rotate-bg before:w-[60%] before:h-[160%] h-full mx-4 w-[90%] xs:w-[70%] sm:w-fit min-w-[18rem] lg:open:max-w-[20rem] lg:min-w-[20rem] ",
                        isAnimated
                           ? `transition-all  duration-[0.3s] delay-100 ease-in opacity-100 scale-100`
                           : "opacity-0 scale-95"
                     )}
                  >
                     {/* card Items */}
                     <div
                        className={clsx(
                           "  w-full h-full rounded-xl p-4 grid justify-center ",
                           index === 1 ? " bg-darkblue" : "bg-darkbg"
                        )}
                     >
                        {/* card header */}
                        <div className=" flex justify-between items-center">
                           <h2 className="  font-bold ">{card.title}</h2>
                           {index === 1 && (
                              <div className=" border-[0.7px] border-white/30 bg-darkbg h-full  rounded-full px-3 py-1 text-xs">
                                 popular
                              </div>
                           )}
                        </div>

                        {/* card pricing */}
                        <p className=" my-4 text-2xl md:text-3xl font-bold flex gap-[2px] w-fit h-fit  text-prominenttext">
                           {/* <span className=" text-2xl md:text-3xl">$</span> */}
                           {card.beforePrice !== "" && (
                              <>
                                 <span className="cutprice">
                                    ${card.beforePrice}
                                 </span>
                                 <span className="text-2xl md:text-3xl">/</span>
                              </>
                           )}

                           <span className="">{card.price}</span>
                        </p>

                        {/* card button */}
                        <button
                           className=" w-full border border-blueish transition-all duration-[0.3s]  hover:bg-blueish hover:scale-105 py-2 rounded-md"
                           onClick={() => handlePurchase(card.name)}
                        >
                           Get Started
                        </button>

                        {/* card features */}
                        <div className=" mt-3 grid gap-1">
                           {card.features.map((feature, i) => (
                              <div className="flex  leading-5 pt-[3px]" key={i}>
                                 <Check className=" w-[8%] mr-2 mt-[2px] stroke-prominenttext" />
                                 <span className="w-[92%]">{feature}</span>
                              </div>
                           ))}
                        </div>
                     </div>
                  </div>
               ))}
            </div>
         </div>
      </section>
   )
}
