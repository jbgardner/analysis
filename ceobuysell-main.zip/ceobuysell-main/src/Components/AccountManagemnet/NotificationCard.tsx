import { Checkbox } from "@mui/material"
import { UserT, settingsT } from "../../utils/interfaces&Types"
import { useState } from "react"
import toast from "react-hot-toast"
import { removeDuplicates, stringCleaner } from "../../utils/Helper"
import supabase from "../../Services/auth.service"
import { TrashI } from "../../assets/Icons/Icons"

export function NotificationCard({
   user,
   setUser,
   handleAddNumber,
   settings,
   setSettings,
}: {
   user: UserT
   setUser: (arg: UserT) => void
   setSettings: React.Dispatch<React.SetStateAction<settingsT>>
   settings: settingsT
   handleAddNumber: () => void
}) {
   const [watchlist, setWatchList] = useState("")

   // Insert watchlist items into the database and update user state
   const insertWatchlist = async (tickerList: string[]) => {
      // ADD new tickers
      if (tickerList) {
         for (let index = 0; index < tickerList.length; index++) {
            const { error } = await supabase.from("watchlist").insert({
               user_id: user.user_id,
               name: tickerList[index],
            })

            if (error) throw new Error(error.message)
         }

         let watchlist = tickerList
         if (user.watchlist) {
            watchlist = user.watchlist.concat(tickerList)
         }

         setUser({ ...user, watchlist })
      }
      setWatchList("")
   }

   const findListDifferences = (list: string[]) => {
      if (watchlist && user && user.watchlist) {
         const { watchlist } = user

         let resultantFilters = removeDuplicates(list)
         resultantFilters = resultantFilters.filter(
            (value) => !watchlist.includes(value)
         )
         // Return null if there are no available tickers after filtering
         return resultantFilters.length > 0 ? resultantFilters : null
      }
      return null
   }

   // Handle adding watchlist with toast notification
   const handleAddWatchlist = () => {
      const tickerList = findListDifferences(
         stringCleaner(watchlist).split(",")
      )
      if (tickerList)
         toast.promise(
            insertWatchlist(tickerList),
            {
               loading: "Updating...",
               success: "Successfully updated",
               error: (error) =>
                  error.message || "Something went wrong Please try again",
            },
            { position: "top-center" }
         )
      else {
         toast.error("Already added", {
            position: "top-center",
            duration: 1500,
         })
         setWatchList("")
      }
   }

   const handleKeyPress = (e: { key: string }) => {
      if (e.key === "Enter" && watchlist.length > 0) {
         handleAddWatchlist()
      }
   }

   // remove from watchlist
   const deleteTicker = async (removeTicker: string, list: string[]) => {
      // REMOVE tickers
      const { error } = await supabase
         .from("watchlist")
         .delete()
         .eq("name", removeTicker)
      if (error) throw new Error(error.message)

      const removeFromWatchList = list.filter((value) => value !== removeTicker)

      setUser({ ...user, watchlist: removeFromWatchList })
   }

   const handleDeleteWatchlist = (
      removeTicker: string,
      list: string[] | undefined
   ) => {
      if (list)
         toast.promise(
            deleteTicker(removeTicker, list),
            {
               loading: "removing...",
               success: "Successfully removed",
               error: (error) =>
                  error.message || "Something went wrong Please try again",
            },
            { position: "top-center", duration: 1500 }
         )
   }

   const setEmailNotification = (email_notification: boolean) => {
      setSettings({ ...settings, email_notification })
   }

   const setTextNotification = (text_notification: boolean) => {
      setSettings({ ...settings, text_notification })
   }

   const updateWatchlistNotification = async (watchlist_notification: {
      email_notification: boolean
      text_notification: boolean
   }) => {
      const { error } = await supabase
         .from("users")
         .update({
            watchlist_notification,
         })
         .eq("id", user.user_id)

      if (error) throw new Error(error.message)

      setUser({ ...user, watchlist_notification })
   }

   const setWatchListNotification = (watchlist_notification: {
      email_notification: boolean
      text_notification: boolean
   }) => {
      toast.promise(
         updateWatchlistNotification(watchlist_notification),
         {
            loading: "Updating...",
            success: "Successfully updated",
            error: (error) =>
               error.message || "Something went wrong Please try again",
         },
         { position: "top-center", duration: 1500 }
      )
   }

   return (
      <section className="w-full grid gap-4 h-fit mx-auto sm:mx-0 bg-darkfg rounded-lg p-4 md:p-6">
         <h1 className="account-management-conatiners-heading">
            Notifications
         </h1>

         {/* ============================= ACTIVIY ============================= */}
         <article className=" relative w-full h-full grid gap-4 sm:grid-cols-[65%,33%] border-b pb-5 border-white/20">
            <div className=" ">
               <h2 className=" text-xl sm:text-2xl font-bold">Activity</h2>
               <p className="flex gap-4 items-center text-white/70">
                  Receive a notification when any CEO purchases or sells new
                  shares.
               </p>
            </div>
            {/* ======= CHECKBOX ACTIVIY COL ======= */}
            <div className="w-full h-full grid justify-normal md:justify-center">
               <div className=" whitespace-nowrap flex items-center gap-1 flex-nowrap">
                  <Checkbox
                     checked={settings.email_notification}
                     onChange={() =>
                        setEmailNotification(!settings.email_notification)
                     }
                     inputProps={{ "aria-label": "controlled" }}
                     sx={{ ml: "-8px" }}
                  />
                  <p className=" text-[rgb(198,198,198)] ">Email</p>
               </div>

               <div className="whitespace-nowrap flex items-center gap-1 flex-nowrap">
                  <Checkbox
                     checked={settings.text_notification}
                     onChange={() =>
                        setTextNotification(!settings.text_notification)
                     }
                     inputProps={{ "aria-label": "controlled" }}
                     disabled={!user.phone}
                     sx={{ ml: "-8px" }}
                  />
                  <p className=" text-[rgb(198,198,198)] ">Text</p>
               </div>
               {!user.phone && (
                  <p
                     className=" -mt-2 underline text-blueish cursor-pointer"
                     onClick={handleAddNumber}
                  >
                     Verify your phone number
                  </p>
               )}
            </div>
         </article>

         {/* ============================= WATCHLIST ============================= */}
         <article className="relative w-full h-full grid gap-4 pb-5 border-b-border-white/20">
            <div className="w-full h-full grid gap-4 sm:grid-cols-[65%,33%]">
               <div className=" ">
                  <h2 className=" text-xl sm:text-2xl font-bold">Watchlist</h2>
                  <p className="flex gap-4 items-center text-white/70">
                     Receive a notification when a CEO of one of the following
                     companies purchases or sells shares.
                  </p>
               </div>
               {/* ======= CHECKBOX WATCHLIST COL ======= */}
               <div className="w-full h-full grid justify-normal md:justify-center">
                  <div className=" whitespace-nowrap flex  items-center gap-1 flex-nowrap">
                     <Checkbox
                        checked={user.watchlist_notification.email_notification}
                        onChange={() =>
                           setWatchListNotification({
                              text_notification:
                                 user.watchlist_notification.text_notification,
                              email_notification:
                                 !user.watchlist_notification
                                    .email_notification,
                           })
                        }
                        inputProps={{ "aria-label": "controlled" }}
                        sx={{ ml: "-8px" }}
                     />
                     <p className=" text-[rgb(198,198,198)] ">Email</p>
                  </div>

                  <div className="whitespace-nowrap flex items-center gap-1 flex-nowrap">
                     <Checkbox
                        checked={user.watchlist_notification.text_notification}
                        onChange={() =>
                           setWatchListNotification({
                              text_notification:
                                 !user.watchlist_notification.text_notification,
                              email_notification:
                                 user.watchlist_notification.email_notification,
                           })
                        }
                        inputProps={{ "aria-label": "controlled" }}
                        disabled={!user.phone}
                        sx={{ ml: "-8px" }}
                     />
                     <p className=" text-[rgb(198,198,198)] ">Text</p>
                  </div>
                  {!user.phone && (
                     <p
                        className=" -mt-2 underline text-blueish cursor-pointer"
                        onClick={handleAddNumber}
                     >
                        Verify your phone number
                     </p>
                  )}
               </div>
            </div>
            {/* ======= REMOVE WATCHLIST ======= */}
            {user.watchlist && (
               <div className=" flex flex-wrap gap-y-2 gap-x-3">
                  {user.watchlist.map((ticker, index) => (
                     <button
                        className=" grid grid-cols-[1fr,1.3rem] gap-3 items-center px-2 py-1 rounded-md border border-white/20 group"
                        onClick={() =>
                           handleDeleteWatchlist(ticker, user.watchlist)
                        }
                        key={index}
                     >
                        <p className=" max-w-sm overflow-hidden text-ellipsis">
                           {ticker}
                        </p>
                        <TrashI className=" w-[1.3rem] h-[1.1rem] fill-white/80 px-[2px] /rounded-md group-hover:fill-blueish" />
                     </button>
                  ))}
               </div>
            )}
            {/* ======= ADD WATCHLIST ======= */}
            <div className=" relative h-[2.62rem] flex flex-nowrap items-center gap-4  w-full ">
               <input
                  type="text"
                  placeholder=" Watch List"
                  className="bg-black border-2 px-3 py-2 rounded-lg outline-none w-full"
                  value={watchlist}
                  onChange={(e) => {
                     setWatchList(e.target.value)
                  }}
                  onKeyUp={handleKeyPress}
               />
               <button
                  onClick={handleAddWatchlist}
                  disabled={watchlist.length <= 0}
                  className={`text-left text-sm lg:text-base w-fit flex items-center justify-center whitespace-nowrap border transition-color duration-[0.2s] px-3 py-2 rounded-lg
                        ${
                           watchlist.length <= 0
                              ? " brightness-50 borer-white/20"
                              : "border-blueish hover:bg-blueish"
                        }
                        `}
               >
                  <span>Add </span>
                  <span className=" hidden sm:block indent-1">
                     {" "}
                     To Watchlist{" "}
                  </span>
               </button>
            </div>
         </article>

         {/* ============================= OTHERS ============================= */}
      </section>
   )
}

// card dimentions
// md:
// w= 908px
// h= 159px
// sm:
// w= 861px
// h= 207px
// xs:
// w= 213px
// h= 439px

// lIST DIFFRENCESS

// if (user.watchlist) {
//    const { watchlist } = user

//    let resultantFilters = list.split(",")
//    const inList = resultantFilters.filter(
//       (value) => !watchlist.includes(value)
//    )

//    const notInList = watchlist.filter(
//       (value) => !resultantFilters.includes(value)
//    )

//    if (notInList.length <= 0 && inList.length <= 0) return null

//    const result = {
//       notInList: notInList.length > 0 ? notInList : null,
//       inList: inList.length > 0 ? inList : null,
//    }
//    // Return null if there are no available tickers after filtering
//    return result
// }
// return null const { ticker } = filters

// INSET FILTERED LIST
