import { FC } from "react"
import { UserT, customNotificationsT } from "../../utils/interfaces&Types"
import { getConciseDateAndTime } from "../../utils/Helper"
import { examples, marketCapMap, sectorsMap } from "../../utils/Constants"
import { Checkbox } from "@mui/material"
import { Link } from "react-router-dom"
import { XI } from "../../assets/Icons/Icons"
import supabase from "../../Services/auth.service"
import { useAuth } from "../../Hooks/useAuth"
import toast from "react-hot-toast"
import Loader from "../Common/Loader"

type customNotificationsMapperT = {
   customNotifications: customNotificationsT[] | null
   user: UserT
   fetching: boolean
   handleAddNumber: () => void
}

export const CustomNotificationsMapper: FC<customNotificationsMapperT> = ({
   customNotifications,
   user,
   handleAddNumber,
   fetching,
}) => {
   const { fetchCustomNotifications } = useAuth()

   const updateNotification = async (
      notification_settings: {
         email_notification: boolean
         text_notification: boolean
      },
      id: string
   ) => {
      const { error } = await supabase
         .from("custom_notifications")
         .update({
            settings: notification_settings,
         })
         .eq("id", id)

      if (error) throw new Error(error.message)

      await fetchCustomNotifications(user.user_id)
   }

   const handleUpdateNotification = (
      notification_settings: {
         email_notification: boolean
         text_notification: boolean
      },
      id: string
   ) => {
      toast.promise(
         updateNotification(notification_settings, id),
         {
            loading: "Updating...",
            success: "Successfully updated",
            error: (error) =>
               error.message || "Something went wrong Please try again",
         },
         { position: "top-center" }
      )
   }

   // remove from watchlist
   const deleteNotification = async (id: string) => {
      // REMOVE tickers
      const { error } = await supabase
         .from("custom_notifications")
         .delete()
         .eq("id", id)
      if (error) throw new Error(error.message)

      await fetchCustomNotifications(user.user_id)
   }

   const handleDeleteNotification = (id: string) => {
      toast.promise(
         deleteNotification(id),
         {
            loading: "removing...",
            success: "Successfully removed",
            error: (error) =>
               error.message || "Something went wrong Please try again",
         },
         { position: "top-center" }
      )
   }

   return (
      <section className="w-full grid gap-4 h-fit mx-auto sm:mx-0 bg-darkfg rounded-lg p-4 md:p-6 lg:p-8">
         <h1 className="account-management-conatiners-heading">
            Custom Notifications
         </h1>

         {fetching && (
            <div className="w-full grid gap-4 h-[20rem] mx-auto sm:mx-0 bg-darkfg rounded-lg p-4 md:p-6">
               <Loader size={30} />
            </div>
         )}

         {customNotifications && (
            <div className=" grid gap-y-6">
               {customNotifications.map((customNotification, index) => {
                  const {
                     ticker,
                     q,
                     sector,
                     market_cap,
                     share_count_min,
                     share_count_max,
                     share_price_min,
                     share_price_max,
                     total_amount_min,
                     total_amount_max,
                     total_share_owned_min,
                     total_share_owned_max,
                     ownership_increase_min,
                     ownership_increase_max,
                     total_share_min,
                     total_share_max,
                     created_at,
                     id,
                     transaction_type,
                  } = customNotification

                  const dateTime = getConciseDateAndTime(created_at)

                  return (
                     <div
                        className="relative w-full h-fit bg-darkbg shadow-lg shadow-black/80 border border-white/20 rounded-lg p-4 md:p-6 sm:grid grid-cols-[82%,18%] "
                        key={index}
                     >
                        <div className=" absolute hidden sm:flex gap-2 items-center top-3 right-7">
                           {dateTime && (
                              <p className=" flex flex-wrap gap-2 text-sm w-fit">
                                 <span className=" text-white/50 underline underline-offset-2">
                                    Live From:
                                 </span>
                                 <span className=" italic">
                                    {dateTime.date}.
                                 </span>
                                 <span className="ml-1 italic">
                                    {dateTime.time}
                                 </span>
                              </p>
                           )}
                        </div>
                        <div className=" absolute flex gap-2 items-center -top-2 -right-2">
                           <button
                              className=" w-fit grid items-center bg-darkfg rounded-lg border p-[2px] border-white/20 group"
                              title="remove"
                              onClick={() => handleDeleteNotification(id)}
                           >
                              <XI className=" w-[1.4rem] h-[1.4rem] stroke-white/80 px-[2px] group-hover:stroke-blueish" />
                           </button>
                        </div>
                        <article>
                           <ul className=" grid gap-y-1 h-fit">
                              {dateTime && (
                                 <p className=" flex sm:hidden flex-wrap gap-x-2 text-sm w-fit mb-3">
                                    <span className=" text-white/50 underline underline-offset-2">
                                       Live From:
                                    </span>
                                    <span className=" italic">
                                       {dateTime.date}.
                                    </span>
                                    <span className=" italic">
                                       {dateTime.time}
                                    </span>
                                 </p>
                              )}
                              <p className=" font-bold text-white/80">
                                 Receive notifications when:
                              </p>
                              {transaction_type && (
                                 <li className=" customnotifications-continer">
                                    <span className=" customnotifications-lablel">
                                       Transaction type:
                                    </span>
                                    <span className=" customnotifications-value">
                                       {" "}
                                       {transaction_type === "S"
                                          ? "Sell"
                                          : "Purchase"}
                                    </span>
                                 </li>
                              )}
                              {q && (
                                 <li className=" customnotifications-continer">
                                    <span className=" customnotifications-lablel">
                                       Company/CEO name:
                                    </span>
                                    <span className=" customnotifications-value">
                                       {" "}
                                       {q}
                                    </span>
                                 </li>
                              )}
                              {ticker && (
                                 <li className=" customnotifications-continer">
                                    <span className=" customnotifications-lablel">
                                       Tickers:
                                    </span>
                                    <span className=" customnotifications-value">
                                       {ticker.replace(/,/g, ", ")}
                                    </span>
                                 </li>
                              )}
                              {market_cap && (
                                 <li className=" customnotifications-continer">
                                    <span className=" customnotifications-lablel">
                                       Market Capital:
                                    </span>
                                    <span className=" customnotifications-value">
                                       {" "}
                                       {marketCapMap[market_cap - 1]}
                                    </span>
                                 </li>
                              )}

                              {sector && (
                                 <li className=" customnotifications-continer">
                                    <span className=" customnotifications-lablel">
                                       Sector:
                                    </span>
                                    <span className=" customnotifications-value">
                                       {" "}
                                       {sectorsMap[sector]}
                                    </span>
                                 </li>
                              )}
                              <CustomNotificationMinMax
                                 min={share_count_min}
                                 max={share_count_max}
                                 label="Share count"
                              />
                              <CustomNotificationMinMax
                                 min={total_amount_min}
                                 max={total_amount_max}
                                 label="Total amount"
                                 addDollar
                              />
                              <CustomNotificationMinMax
                                 min={share_price_min}
                                 max={share_price_max}
                                 label="Share price"
                                 addDollar
                              />
                              <CustomNotificationMinMax
                                 min={total_share_owned_min}
                                 max={total_share_owned_max}
                                 label="Share owned"
                              />
                              <CustomNotificationMinMax
                                 min={total_share_min}
                                 max={total_share_max}
                                 label="Total share"
                              />
                              <CustomNotificationMinMax
                                 min={ownership_increase_min}
                                 max={ownership_increase_max}
                                 label="Ownership increase"
                                 addPercent
                              />
                           </ul>
                        </article>
                        <aside className="w-full h-full grid justify-end items-end pr-4 mt-4 ">
                           <div className="w-full h-fit ">
                              <div className=" whitespace-nowrap flex items-center gap-1 flex-nowrap">
                                 <Checkbox
                                    checked={
                                       customNotification.settings
                                          .email_notification
                                    }
                                    onChange={() =>
                                       handleUpdateNotification(
                                          {
                                             text_notification:
                                                customNotification.settings
                                                   .text_notification,
                                             email_notification:
                                                !customNotification.settings
                                                   .email_notification,
                                          },
                                          id
                                       )
                                    }
                                    inputProps={{ "aria-label": "controlled" }}
                                    sx={{ ml: "-8px" }}
                                 />
                                 <p className=" text-[rgb(198,198,198)] ">
                                    Email
                                 </p>
                              </div>

                              <div className="whitespace-nowrap flex items-center gap-1 flex-nowrap">
                                 <Checkbox
                                    checked={
                                       customNotification.settings
                                          .text_notification
                                    }
                                    onChange={() =>
                                       handleUpdateNotification(
                                          {
                                             text_notification:
                                                !customNotification.settings
                                                   .text_notification,
                                             email_notification:
                                                customNotification.settings
                                                   .email_notification,
                                          },
                                          id
                                       )
                                    }
                                    inputProps={{
                                       "aria-label": "controlled",
                                    }}
                                    disabled={!user.phone}
                                    sx={{ ml: "-8px" }}
                                 />
                                 <button
                                    onClick={handleAddNumber}
                                    disabled={user.phone ? true : false}
                                    className={`text-[rgb(198,198,198)] ${
                                       !user.phone && "hover:text-blueish"
                                    } `}
                                 >
                                    Text
                                 </button>
                              </div>
                           </div>
                        </aside>
                     </div>
                  )
               })}
            </div>
         )}

         <article className="relative w-full h-full grid gap-4 pb-5">
            <p className=" text-white/70 my-1">
               <span>To create a custom notification, go to the </span>
               <Link className=" underline text-blueish " to="/search">
                  Search Screen
               </Link>
               <span> and click the "+" button.</span>
            </p>
            <h2 className=" text-xl sm:text-2xl font-bold">
               Here are some ideas:
            </h2>

            {/* ======= examples ======= */}
            <div className=" relative w-full h-full grid gap-4 sm:grid-cols-2 md:grid-cols-3">
               {examples.map((example, index) => (
                  <Link
                     key={index}
                     to={example.paramValue}
                     className=" w-full h-fit grid text-left items-center justify-center border border-blueish transition-all duration-[0.3s] disabled:hover:bg-transparent hover:bg-blueish px-3 py-[0.35rem] rounded-xl"
                  >
                     {example.text}
                  </Link>
               ))}
            </div>
         </article>
      </section>
   )
}

const CustomNotificationMinMax: FC<{
   min?: number
   max?: number
   label: string
   addDollar?: boolean
   addPercent?: boolean
}> = ({ min, max, label, addDollar, addPercent }) => {
   if (min || max)
      return (
         <li className=" customnotifications-continer">
            <span className=" customnotifications-lablel">{label}</span>
            {max && (
               <>
                  <span className=" customnotifications-lablel">
                     is less than:
                  </span>
                  <span className=" customnotifications-value">
                     {addDollar && "$"}
                     {max.toLocaleString()}
                     {addPercent && "%"}
                  </span>
               </>
            )}
            {max && min ? (
               <span className=" customnotifications-lablel">and </span>
            ) : (
               !max &&
               min && <span className=" customnotifications-lablel"> is </span>
            )}
            {min && (
               <>
                  <span className=" customnotifications-lablel">
                     greater than:
                  </span>
                  <span className=" customnotifications-value">
                     {addDollar && "$"}
                     {min.toLocaleString()}
                     {addPercent && "%"}
                  </span>
               </>
            )}
         </li>
      )
}
