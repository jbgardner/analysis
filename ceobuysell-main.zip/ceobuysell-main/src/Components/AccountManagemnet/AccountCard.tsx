import clsx from "clsx"
import { stripeUserPortal } from "../../Services/auth.service"
import {
   CrownI,
   LogoutI,
   MailI,
   PhoneI,
   ProfileReplacmentI,
} from "../../assets/Icons/Icons"
import { UserT, settingsT } from "../../utils/interfaces&Types"
import { DailyDigestAndWeeklyReport } from "./DailyDigestAndWeeklyReport"

export function AccountCard({
   user,
   settings,
   setSettings,
   handleAddNumber,
   logout,
}: {
   user: UserT
   handleAddNumber: () => void
   logout: () => void
   setSettings: React.Dispatch<React.SetStateAction<settingsT>>
   settings: settingsT
}) {
   const setDailyDigest = (daily_digest: boolean) => {
      setSettings({ ...settings, daily_digest })
   }

   const setWeeklySectorReport = (weekly_sector_report: boolean) => {
      setSettings({ ...settings, weekly_sector_report })
   }

   const handleBilling = async (customer_id: string) => {
      try {
         const res = await stripeUserPortal(customer_id)
         const session_url = res.data.session_url
         window.location.href = session_url
      } catch (error) {
         console.error("Error in handling billing request:", error)
      }
   }

   return (
      <section className=" w-full h-fit sm:w-[26rem] mx-auto sm:mx-0 bg-darkfg rounded-2xl p-4 md:p-6">
         <h1 className="account-management-conatiners-heading mb-4">Account</h1>
         {/* ======= ACOUNT MANAGEMENT USER DATA ======= */}
         <div className="xs:flex gap-5 w-full h-full ">
            <div
               className={clsx(
                  "w-[3.25rem] h-14 rounded-lg border-white border shrink-0 ",
                  user.phone && "my-4"
               )}
            >
               <ProfileReplacmentI className="w-full h-full  fill-white shrink-0" />
            </div>
            <div className=" ">
               <h2 className=" text-xl sm:text-2xl font-bold">{user.name}</h2>
               <p className="flex gap-3 items-center ">
                  <MailI className=" h-5 w-5 fill-white md:shrink-0" />
                  <span className="text-ellipsis w-[14.5rem] xs:w-[16.5rem] overflow-hidden  text-white/70">
                     {user.email}
                  </span>
               </p>
               {user.phone && (
                  <p className="flex gap-3 items-center ">
                     <PhoneI className=" h-5 w-5 stroke-white md:shrink-0" />
                     <span className="text-ellipsis w-[14.5rem] xs:w-[16.5rem] overflow-hidden  text-white/70">
                        {user.phone}
                     </span>
                  </p>
               )}
            </div>
         </div>

         {/* ======= ACOUNT MANAGEMENT SETTING CARD ======= */}
         <div className=" mt-4 grid gap-y-4">
            <DailyDigestAndWeeklyReport
               name="daily_digest"
               card="DocI"
               enabled={settings.daily_digest}
               setEnabled={setDailyDigest}
            />
            {/* ======= WEEKLY REPORT ======= */}
            <DailyDigestAndWeeklyReport
               name="text_notification"
               card="StatsI"
               enabled={settings.weekly_sector_report}
               setEnabled={setWeeklySectorReport}
            />

            {/* ======= BILLIG ======= */}
            <div className="flex flex-wrap xs:flex-nowrap gap-2 md:gap-3 justify-between h-fit w-full border border-white/20 p-2 rounded-2xl my-1">
               <div className=" flex items-center gap-1 md:gap-2">
                  <div className=" bg-black p-2 h-fit w-fit rounded-xl">
                     <CrownI className=" h-6 md:h-7 w-6 md:w-7" />
                  </div>
                  <p className=" text-sm md:text-base leading-5">
                     You are on the {user.plan}
                  </p>
               </div>
               {user.customer_id && (
                  <button
                     onClick={() =>
                        user.customer_id && handleBilling(user.customer_id)
                     }
                     className=" whitespace-nowrap md:text-[1.2rem] w-fit h-fit grid items-center justify-center border border-blueish transition-all duration-[0.3s] hover:bg-blueish px-3 py-[0.35rem] rounded-xl"
                  >
                     Manage billing
                  </button>
               )}
            </div>

            {!user.phone && (
               <button
                  onClick={handleAddNumber}
                  className=" text-left w-full grid items-center justify-center border border-blueish transition-all duration-[0.3s] hover:bg-blueish px-3 py-2 rounded-xl"
               >
                  Verify your phone number to start receiving text notification.
               </button>
            )}
            <button
               onClick={logout}
               className="flex justify-between items-center w-full py-2 px-3 stroke-white border border-blueish transition-all duration-[0.3s]  hover:bg-blueish rounded-xl"
            >
               <div>Logout</div>
               <LogoutI className="h-4 stroke-[1.3] " />
            </button>
         </div>
      </section>
   )
}
