import { FC } from "react"
import { ClassProps } from "../../utils/interfaces&Types"
import { Switch } from "@headlessui/react"

import { DocI, StatsI } from "../../assets/Icons/Icons"

type settingsCardPropsT = {
   card: "DocI" | "StatsI"
   name: string
   enabled: boolean
   setEnabled: (arg: boolean) => void
}

export const DailyDigestAndWeeklyReport: FC<settingsCardPropsT> = ({
   card,
   name,
   enabled,
   setEnabled,
}): JSX.Element => {
   const iconMap: { [key: string]: FC<ClassProps> } = {
      DocI,
      StatsI,
   }

   const paraMap: { [key: string]: string } = {
      DocI: "Daily digest",
      StatsI: "Weekly sector report",
   }

   const para = paraMap[card]
   const Icon = iconMap[card]
   return (
      <div className="flex flex-wrap xs:flex-nowrap gap-2 md:gap-3 justify-between h-fit w-full border border-white/20 p-2 rounded-2xl my-1">
         <div className=" flex items-center gap-1 md:gap-2">
            <div className=" bg-black p-2 h-fit w-fit rounded-xl">
               <Icon className=" h-6 md:h-7 w-6 md:w-7" />
            </div>
            <p className=" text-sm md:text-base leading-5">{para}</p>
         </div>

         <div className=" grid items-center ">
            <Switch
               checked={enabled}
               onChange={setEnabled}
               name={name}
               className={` relative inline-flex h-[1.275rem] md:h-[1.5rem] w-[2.28rem]  md:w-[2.75rem] shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus-visible:ring-2  focus-visible:ring-white/75
                  ${enabled ? "bg-blueish" : "bg-teal-900"}
                  `}
            >
               <span className="sr-only">Use setting</span>
               <span
                  aria-hidden="true"
                  className={`${
                     enabled
                        ? "translate-x-4 md:translate-x-5"
                        : "translate-x-0"
                  }
            pointer-events-none inline-block h-[1.05rem] md:h-[1.25rem] w-[1.05rem] md:w-[1.25rem] transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out`}
               ></span>
            </Switch>
         </div>
      </div>
   )
}
