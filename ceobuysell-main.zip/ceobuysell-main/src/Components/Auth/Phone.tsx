import { FormEvent, useState } from "react"
import { useAuth } from "../../Hooks/useAuth"
import Loader from "../Common/Loader"
import clsx from "clsx"
import toast from "react-hot-toast"
import { requestOtp, verfiyOtp } from "../../Services/user.services"
import supabase from "../../Services/auth.service"

export const Phone = () => {
   const [phone, setPhone] = useState<string>("")
   const [otp, setOtp] = useState<string>("")
   const [loading, setLoading] = useState<boolean>(false)
   const [verificationSend, setVerificationSend] = useState<boolean>(false)

   const { user, setModelIndex, setOpenModel, setUser } = useAuth()

   if (!user) {
      toast.error("please login to add number")
      setModelIndex(0)
      return
   }

   const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
      e.preventDefault()

      const numberRegex = /^[+]?\d+(\.\d+)?$/
      const phoneRegex = /^\+1(\d{10})$/
      try {
         setLoading(true)
         if (!verificationSend) {
            if (phone.length <= 0) {
               toast.error("Please fill in phone field")
               return setLoading(false)
            }

            if (!phoneRegex.test(phone)) {
               toast.error("Invalid Phone Number")
               return setLoading(false)
            }

            await requestOtp({ phone })
            toast.success("OTP has been sent to your number.")
            setVerificationSend(true)
            setLoading(false)
            return
         } else {
            if (otp.length !== 6) {
               toast.error("Invalid OTP!")
               return setLoading(false)
            }

            if (!numberRegex.test(otp)) {
               toast.error("Invalid OTP!")
               return setLoading(false)
            }

            const res = await verfiyOtp({ phone, code: otp })
            const { status } = res.data

            if (status && status !== "pending") {
               const { error } = await supabase
                  .from("users")
                  .update({ phone: phone })
                  .eq("id", user.user_id)

               if (error) {
                  toast.error(error.message)
                  return setLoading(false)
               }

               toast.success("Phone number added successfully.")
               setUser({ ...user, phone: phone })
               setOpenModel(false)
            } else {
               toast.error("Invalid OTP!")
            }

            return setLoading(false)
         }
      } catch (error: any) {
         setLoading(false)
         console.log(error.response.data.detail)
         console.log(error)

         toast.error(
            error.message
               ? "Something went wrong please try again. Remember we only provide phone services for Canada and USA."
               : "Something went wrong please try again."
         )
      }
   }

   return (
      <form
         className="grid text-left gap-3 sm:gap-4 mb-4"
         onSubmit={handleSubmit}
      >
         <div className=" mb-3">
            <p className=" text-xl sm:text-2xl md:text-3xl ">
               Enter your phone number
            </p>
            <p className=" mt-2 text-white">
               Keep track of the all the activities on insider tradings of CEO's
               by getting
               <span className=" text-prominenttext"> SMS </span>
               reports.
            </p>
            <p className=" mt-2 bg-darkfg border border-white/10 p-2 md:p-4 rounded-md text-slate-200">
               <span className=" font-bold ">
                  Note: We only provide phone services for Canada and USA.
               </span>
               <br />
               <span className=" font-light ">
                  Please contact us at
                  <span className=" text-white mx-2 font-medium">
                     info@ceobuysell.com
                  </span>
                  if you would like to use a phone number from another country.
               </span>
            </p>
         </div>
         <label className="text-white">
            <span className="block mb-1 ">Phone</span>
            <input
               type="text"
               className="w-full p-2 rounded-md bg-inputColor/60 outline-none "
               value={phone}
               onChange={(e) => setPhone(e.target.value)}
               placeholder="+12345678999"
               name="phone"
               autoFocus
            />
         </label>

         <label
            className={clsx(
               "text-white transition-all ease-in-out duration-300 delay-100",
               verificationSend ? "opacity-100  " : "opacity-0  "
            )}
         >
            <span className="block mb-1 ">Enter Verfication OTP</span>
            <input
               type="text"
               className={clsx(
                  "w-full p-2 rounded-md bg-inputColor/60 outline-none transition-all ease-in-out duration-300 ",
                  verificationSend ? "opacity-100 " : "opacity-0 "
               )}
               disabled={!verificationSend}
               onChange={(e) => setOtp(e.target.value)}
               placeholder="Enter OTP"
               name="otp"
               autoFocus
            />
         </label>
         <div
            className={clsx(
               "transition-all ease-in-out duration-500",
               verificationSend ? " translate-y-0" : "-translate-y-24"
            )}
         >
            <button
               type="submit"
               className="flex justify-center items-center mt-4 py-2 sm:text-[1.2rem] w-full rounded-md border border-blueish transition-all ease-in-out duration-200  hover:bg-blueish"
            >
               {verificationSend ? "Verfy OTP" : "Send OTP"}
               {loading && <Loader className=" max-w-[2rem]" size={20} />}
            </button>
         </div>
      </form>
   )
}
