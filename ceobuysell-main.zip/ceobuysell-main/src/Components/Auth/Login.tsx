import { useState } from "react"
import { useAuth } from "../../Hooks/useAuth"
import Loader from "../Common/Loader"

export const Login = () => {
   const [credentials, setCredentials] = useState({
      email: "",
      password: "",
   })

   const { setModelIndex, login, loading } = useAuth()

   const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const { name, value } = e.target
      setCredentials({ ...credentials, [name]: value })
   }

   const handleLogin = async (e: { preventDefault: () => void }) => {
      e.preventDefault()
      // login user
      login(credentials)
   }

   return (
      <form className="grid text-left gap-3  mb-4 ">
         <div className="mb-2">
            <p className="text-xl sm:text-2xl md:text-3xl ">
               Welcome back{" "}
               <span className=" italic text-prominenttext">!</span>
            </p>
            <p className=" text-white/70 mt-1">
               Sign in to your account to continue.
            </p>
         </div>
         <label className="text-white">
            <span className="block mb-1 ">Email</span>
            <input
               type="email"
               className="w-full p-2 rounded-md bg-inputColor/60 outline-none "
               value={credentials.email}
               name="email"
               onChange={handleChange}
               autoFocus
            />
         </label>

         <label className="text-white">
            <span className="block mb-1 ">Password</span>
            <input
               type="password"
               className="w-full p-2 rounded-md bg-inputColor/60 outline-none"
               value={credentials.password}
               name="password"
               onChange={handleChange}
            />
         </label>

         <button
            className="flex justify-center mt-4 py-2 sm:text-[1.2rem] px-8 rounded-md border border-blueish transition-all duration-200  hover:bg-blueish"
            onClick={handleLogin}
         >
            Login
            {loading && <Loader className=" max-w-[2rem]" size={20} />}
         </button>

         <p className="text-white text-center">
            Don't have an account?{" "}
            <span
               className="text-indigo-500 cursor-pointer"
               onClick={() => setModelIndex(1)}
            >
               Sign up
            </span>
         </p>
      </form>
   )
}
