/* eslint-disable react-hooks/exhaustive-deps */
import { useState } from "react"

import { useAuth } from "../../Hooks/useAuth"
import { RadioGroup } from "@headlessui/react"
import { pricing } from "../../utils/Constants"

export const Register = () => {
   const [credentials, setCredentials] = useState({
      name: "",
      email: "",
      password: "",
      plan: "lifetime",
   })

   const setPlan = (plan: string) => {
      setCredentials({ ...credentials, plan })
   }

   const { register, setModelIndex } = useAuth()

   const handleChange = (e: { target: { name: any; value: any } }) => {
      const { name, value } = e.target

      setCredentials({ ...credentials, [name]: value })
   }

   const handleRegister = async (e: { preventDefault: () => void }) => {
      e.preventDefault()

      register(credentials)
   }

   return (
      <form className="grid gap-3 mb-4 text-left" onSubmit={handleRegister}>
         <div className="mb-2">
            <p className=" text-xl sm:text-2xl md:text-3xl ">
               Create an account{" "}
               <span className="text-prominenttext">today</span>
            </p>
            <p className=" mt-1 text-white/70">
               Register an account to enjoy all the benefits of our platform.
            </p>
         </div>
         <label className="text-white">
            <span className="block mb-1 ">Name</span>
            <input
               type="text"
               className="w-full p-2 rounded-md bg-inputColor/60 outline-none"
               value={credentials.name}
               name="name"
               onChange={handleChange}
               autoFocus
            />
         </label>

         <label className="text-white">
            <span className="block mb-1 ">Email</span>
            <input
               type="email"
               className="w-full p-2 rounded-md bg-inputColor/60 outline-none"
               value={credentials.email}
               name="email"
               onChange={handleChange}
            />
         </label>

         <label className="text-white">
            <span className="block mb-1 ">Password</span>
            <input
               type="password"
               className="w-full p-2 rounded-md bg-inputColor/60 outline-none"
               value={credentials.password}
               name="password"
               onChange={handleChange}
            />
         </label>

         <RadioGroup
            className="sm:justify-center grid"
            value={credentials.plan}
            onChange={setPlan}
         >
            <RadioGroup.Label className="block mb-2 sm:mb-3 sm:text-center text-white/60">
               Subcription types
            </RadioGroup.Label>

            <div className="flex flex-wrap gap-2 w-full">
               {pricing.plans.map((pricing) => (
                  <RadioGroup.Option
                     key={pricing.name}
                     value={pricing.name}
                     className={`flex flex-wrap gap-2 px-3 py-2 transition-all ease-in-out duration-300 text-center text-white border border-blueish rounded-lg cursor-pointer hover:scale-105 ui-checked:bg-indigo-500`}
                  >
                     {pricing.name}{" "}
                     <span className="block font-bold">{pricing.price}</span>
                  </RadioGroup.Option>
               ))}
            </div>
         </RadioGroup>
         <div className="mt-5">
            <p className="text-xs">
               By joining, you agree to our{" "}
               <a
                  className="font-bold hover:underline"
                  href="/terms-and-conditions"
               >
                  Terms of Service
               </a>{" "}
               and{" "}
               <a className="hover:underline font-bold" href="/privacy-policy">
                  Privacy Policy.
               </a>
            </p>
            <button
               type="submit"
               className="flex w-full justify-center mt-2 py-2 sm:text-[1.2rem] px-8 rounded-md border border-blueish transition-all duration-200  hover:bg-blueish"
            >
               Continue with payment
            </button>
         </div>

         <p className="text-center text-white">
            Already have an account?{" "}
            <span
               className="text-indigo-500 cursor-pointer"
               onClick={() => setModelIndex(0)}
            >
               Sign In
            </span>
         </p>
      </form>
   )
}
