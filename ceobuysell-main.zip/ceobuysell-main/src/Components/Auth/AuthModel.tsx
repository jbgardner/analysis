import { FC, Fragment } from "react"
import { Transition, Dialog, Tab } from "@headlessui/react"
import { Register } from "./Register"
import { Login } from "./Login"
import { useAuth } from "../../Hooks/useAuth"
import { CloseI } from "../../assets/Icons/Icons"
import { ModalPropsT } from "../../utils/interfaces&Types"
import { Phone } from "./Phone"

const AuthModal: FC<ModalPropsT> = ({ open, setOpen }) => {
   const { modelIndex, setModelIndex } = useAuth()

   return (
      <Transition appear show={open} as={Fragment}>
         <Dialog
            as="div"
            open={open}
            className="relative z-50"
            onClose={() => setOpen(false)}
         >
            <Transition.Child
               as={Fragment}
               enter="ease-out duration-300"
               enterFrom="opacity-0"
               enterTo="opacity-100"
               leave="ease-in duration-200"
               leaveFrom="opacity-100"
               leaveTo="opacity-0"
            >
               <div className="fixed inset-0 bg-darkbg/50 backdrop-blur-[1px]" />
            </Transition.Child>

            <div className="fixed inset-0 overflow-y-auto">
               <div className="flex min-h-full items-center justify-center p-2 sm:p-4 text-center">
                  <Transition.Child
                     as={Fragment}
                     enter="ease-out duration-300"
                     enterFrom="opacity-0 translate-y-10 scale-[0.2]"
                     enterTo="opacity-100 scale-100"
                     leave="ease-in duration-300"
                     leaveFrom="opacity-100 -translate-y-10 scale-100"
                     leaveTo="opacity-0 scale-95"
                  >
                     <Dialog.Panel className=" relative w-full max-w-[30rem] md:w-[65%] rounded-xl shadow-xl shadow-black/80 my-auto h-[80vh] max-h-[43rem] transition-all">
                        <section className="grid h-full ">
                           <article className=" pt-10 pb-6 px-6 overflow-auto bg-gradient-to-tr from-darkblue to-[rgb(16,6,52)] rounded-xl">
                              {[0, 1].includes(modelIndex) && (
                                 <Tab.Group
                                    selectedIndex={modelIndex}
                                    onChange={setModelIndex}
                                 >
                                    <header className="text-white text-lg md:text-xl">
                                       <Tab.List className="flex gap-2 ">
                                          <Tab className=" px-4 xs:px-6 py-1 transition-colors ease-in-out duration-300 rounded-md shadow ui-selected:shadow-black/50 ui-selected:bg-indigo-900 bg-transparent mb-4">
                                             Login
                                          </Tab>

                                          <Tab className="px-4 xs:px-6 py-1 transition-colors ease-in-out duration-300 rounded-md shadow ui-selected:shadow-black/50 ui-selected:bg-indigo-900 bg-transparent mb-4">
                                             Register
                                          </Tab>
                                       </Tab.List>
                                    </header>

                                    <Tab.Panels className="my-6 h-auto ">
                                       <Tab.Panel className="">
                                          <Login />
                                       </Tab.Panel>

                                       <Tab.Panel className="">
                                          <Register />
                                       </Tab.Panel>
                                    </Tab.Panels>
                                 </Tab.Group>
                              )}
                              {modelIndex === 2 && (
                                 <>
                                    <header className=" text-start w-fit text-lg md:text-xl px-4 xs:px-6 py-1 transition-colors ease-in-out duration-300 border-b  border-indigo-900 mb-4">
                                       Add phone number
                                    </header>
                                    <>
                                       <Phone />
                                    </>
                                 </>
                              )}
                           </article>

                           {/* close button */}
                           <button
                              className="absolute top-5 right-5 group"
                              title="Close"
                              onClick={() => setOpen(false)}
                           >
                              <CloseI className=" fill-white group-hover:fill-slate-200 h-7 w-7" />
                           </button>
                        </section>
                     </Dialog.Panel>
                  </Transition.Child>
               </div>
            </div>
         </Dialog>
      </Transition>
   )
}

export default AuthModal

//  <Transition.Child
//    as={Fragment}
//    enter="ease-out duration-200"
//    enterFrom="opacity-50 translate-x-5 "
//    enterTo="opacity-100 "
//    leave="ease-in duration-200"
//    leaveFrom="opacity-100 -translate-x-5 "
//    leaveTo="opacity-50"
// >
