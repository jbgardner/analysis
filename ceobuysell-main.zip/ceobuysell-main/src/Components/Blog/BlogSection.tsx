// Hooks
import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"

//ghost
import { getSinglePost } from "../../Services/blog.services"
import { PostOrPage } from "tryghost__content-api"

// assets
import "../../Styles/singleBlog.css"

// helpers
import Loader from "../Common/Loader"
import { getConciseDate } from "../../utils/Helper"

// layout
import clsx from "clsx"
import { MailI, Twitter } from "../../assets/Icons/Icons"

export const BlogSection = () => {
   const params = useParams()
   const [blog, setBlog] = useState<null | PostOrPage>(null)
   const [loading, setLoading] = useState<boolean>(true)

   useEffect(() => {
      if (!blog && params.slug)
         getSinglePost(params.slug).then((data) => {
            if (data) {
               setBlog(data)
            }

            window.scrollTo(0, 0)
            setLoading(false)
         })
      else {
         setLoading(false)
         window.scrollTo(0, 0)
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
   }, [])

   return (
      <section className="w-full h-full bg-darkbg/40 pb-10 xs:pb-20 lg:pb-32">
         {!loading ? (
            blog ? (
               <div className=" max-w-maximum mx-auto">
                  <div className=" w-full px-3 sm:w-[80%] mx-auto text-left text-white pt-6 sm:pt-10">
                     {/* Share  */}
                     <div className=" w-full flex justify-end mb-4">
                        <ul className="flex mt-2 space-x-4">
                           <li className=" font-bold uppercase">Share it:</li>
                           <li>
                              {/* twitter */}
                              <a
                                 className="twitter-share-button"
                                 target="_blank"
                                 rel="noreferrer"
                                 href={`https://twitter.com/intent/tweet?text=${blog.title}&url=https://www.ceobuysell.com/blog/${blog.slug}`}
                              >
                                 <Twitter className=" h-6 w-6 fill-white" />
                              </a>
                           </li>

                           {/* mail */}
                           <li>
                              <a
                                 target="_blank"
                                 rel="noreferrer"
                                 href={`mailto:#?subject=${blog.title} - https://www.ceobuysell.com/blog/${blog.slug}`}
                              >
                                 <MailI className=" h-6 w-6 fill-white" />
                              </a>
                           </li>
                        </ul>
                     </div>
                     {/* Title  */}
                     <h1 className="text-2xl font-bold md:text-4xl">
                        {blog.title}
                     </h1>
                     {/* Times  */}
                     <p className=" text-sm space-x-1 text-white/60 font-bold ">
                        <span
                           className={clsx(
                              " uppercase ",
                              !blog.published_at && "hidden"
                           )}
                        >
                           {getConciseDate(blog.published_at)}
                        </span>
                        <span
                           className={clsx(" ", !blog.reading_time && "hidden")}
                        >
                           {" "}
                           -- {blog.reading_time} sec read
                        </span>
                     </p>

                     {/* excerpt */}
                     <p className="text-sm mt-3 mx-auto text-white/50">
                        {blog.custom_excerpt
                           ? blog.custom_excerpt
                           : blog.excerpt}
                     </p>

                     {/* image  */}
                     {blog.feature_image && (
                        <img
                           src={blog.feature_image}
                           alt="Post Image"
                           className="mw-full  rounded-md  mt-4"
                        />
                     )}
                  </div>
                  <div className=" w-full px-3 sm:w-[80%] mx-auto pb-8 ">
                     {/* content */}
                     <article
                        className="w-full blog-content"
                        dangerouslySetInnerHTML={{
                           __html: blog.html as string,
                        }}
                     ></article>
                  </div>
               </div>
            ) : (
               <div className="max-w-maximum h-[40rem] m-auto ">
                  <div className="flex w-full h-full justify-center items-center text-xl font-bold">
                     Sorry article is not currently available!
                  </div>
               </div>
            )
         ) : (
            <div className=" max-w-maximum h-[50rem] m-auto ">
               <Loader size={50} />
            </div>
         )}
      </section>
   )
}
