// Statics
import { Fragment } from "react"
import { LogoutI, ProfileReplacmentI } from "../../assets/Icons/Icons"

// Dropdown
import { useAuth } from "../../Hooks/useAuth"
import { Popover, Transition } from "@headlessui/react"
// hooks
import { Link, useLocation } from "react-router-dom"

// ReactNode main
export const Account = () => {
   const { logout, user } = useAuth()
   const { pathname } = useLocation()
   const loc = pathname.split("/")[1]

   return (
      <Popover className="relative h-full grid items-center justify-end">
         <Popover.Button className=" rounded-full border outline-none border-blueish grid items-center aspect-[1] h-10 ">
            <ProfileReplacmentI className="rounded-full h-full w-full fill-white" />
         </Popover.Button>
         <Transition.Child
            as={Fragment}
            enter="ease-out duration-200"
            enterFrom="opacity-0 translate-x-20 -translate-y-20 scale-50"
            enterTo="opacity-100 scale-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100 scale-100"
            leaveTo="opacity-0 scale-50 translate-x-20  -translate-y-20 "
         >
            <Popover.Panel className="absolute top-14 -right-2 xs:right-0 z-50 block bg-accents shadow-lg shadow-black/50  p-4 w-[18rem] rounded-md  text-base sm:text-lg">
               {({ close }) => (
                  <>
                     <div className=" flex justify-between pb-2">
                        <p className=" text-lg sm:text-xl text-ellipsis w-[16rem] overflow-hidden font-bold leading-7 text-opacity-70 ">
                           Hy, {user?.name} 👋
                           <br />
                           <span className=" md:text-lg font-light text-white/80">
                              {user?.email}
                           </span>
                        </p>
                        {["dashboard", "search"].includes(loc) &&
                           !user?.isPro && (
                              <a
                                 href={`${origin}/#pricing`}
                                 className=" w-fit h-fit text-sm xs:text-base font-extrabold grid md:hidden items-center whitespace-nowrap rounded-full border border-blueish hover:bg-blueish transition-all duration-[0.3s] px-3 lg:px-4 py-1 "
                              >
                                 Go Pro
                              </a>
                           )}
                     </div>
                     {["dashboard", "search"].includes(loc) && (
                        <nav className=" grid gap-2" onClick={() => close()}>
                           <div className=" w-full my-2 border-b border-white/20" />
                           <Link
                              to="/"
                              className=" w-fit grid items-center  border-b border-transparent hover:border-blueish transition-all duration-[0.3s] font-bold hover:translate-x-3 px-3 lg:px-4 py-1 "
                           >
                              Home
                           </Link>

                           <Link
                              to="/search"
                              className=" w-fit grid items-center  border-b border-transparent hover:border-blueish transition-all duration-[0.3s] font-bold hover:translate-x-3 px-3 lg:px-4 py-1 "
                           >
                              Search
                           </Link>
                        </nav>
                     )}
                     <div className=" w-full border-b my-2 border-white/20" />
                     {user?.isPro && (
                        <Link
                           onClick={() => {
                              close()
                           }}
                           to={"/dashboard"}
                           className="  flex justify-between items-center gap-2 my-4 px-3 py-1 h-10 rounded-md  w-full  stroke-white border border-blueish transition-all duration-[0.3s]  hover:bg-blueish hover:scale-105 "
                        >
                           Account Prefrences
                           <ProfileReplacmentI className=" h-9 -mr-3 -ml-1 fill-white " />
                        </Link>
                     )}
                     <button
                        onClick={() => {
                           logout()
                           close()
                        }}
                        className="flex justify-between items-center w-full mt-2 py-1 px-3 h-10 stroke-white border border-blueish transition-all duration-[0.3s]  hover:bg-blueish hover:scale-105 rounded-md"
                     >
                        <div>Logout</div>
                        <LogoutI className="h-4 stroke-[1.3] " />
                     </button>
                  </>
               )}
            </Popover.Panel>
         </Transition.Child>
      </Popover>
   )
}
