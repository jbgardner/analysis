import { searchBarProps } from "../../utils/interfaces&Types"
import { GoforwardI, SearchI } from "../../assets/Icons/Icons"
import { ChangeEvent, useEffect, useState } from "react"
import clsx from "clsx"
import "../../Styles/searchBar.css"
import { hero } from "../../utils/Constants"
import { useLocation, useNavigate } from "react-router-dom"
import { stringCleaner, urlInitializer } from "../../utils/Helper"

export const SearchBar: React.FC<searchBarProps> = ({
   className = "",
   inputClassName = " overflow-hidden h-10 md:h-12 xs:text-lg lg:text-xl pl-11 pr-11 text-white bg-darkfg outline-none rounded-[23.8px] w-full",
}) => {
   const location = useLocation()
   const searchParams = new URLSearchParams(location.search)
   const [searchText, setSearchText] = useState(
      urlInitializer("ticker", "", searchParams).replace(/,/g, ", ")
   )
   const [isButtonClicked, setIsButtonClicked] = useState(false)

   const navigate = useNavigate()

   const loc = location.pathname.split("/")[1]

   const handleTextChange = (event: ChangeEvent<HTMLInputElement>) => {
      const val = event.target.value
      setSearchText(val)
   }

   const handleSearchClick = () => {
      setIsButtonClicked(true)

      const cleanedString = stringCleaner(searchText)
      setSearchText(cleanedString.replace(/,/g, ", "))
      searchParams.set("ticker", cleanedString)
      searchParams.set("offset", "0")
      if (cleanedString.length > 0) navigate(`/search?${searchParams}`)
      else navigate(`/search`)
      setTimeout(() => {
         setIsButtonClicked(false)
      }, 400)
   }

   useEffect(() => {
      const param = searchParams.get("ticker")

      setSearchText(param ? param.replace(/,/g, ", ") : "")
   }, [location.search])

   const handleKeyPress = (e: { key: string }) => {
      if (e.key === "Enter") {
         handleSearchClick()
      }
   }

   return (
      <search
         className={clsx(
            "relative transition-all duration-300 ease-in-out overflow-clip",
            className
         )}
      >
         <div className="absolute inset-y-0 left-0 flex rounded-full  items-center w-[2.5rem] h-full md:w-[3rem] justify-center">
            <SearchI className="  w-6 h-6" />
         </div>

         <input
            type="text"
            placeholder={hero.placeHolder}
            className={inputClassName}
            value={searchText}
            onChange={handleTextChange}
            onKeyDown={handleKeyPress}
         />

         <button
            onClick={handleSearchClick}
            disabled={searchText.length <= 0}
            className={clsx(
               "absolute aspect-[1] h-full inset-y-0 right-0 disabled:hidden flex items-center justify-center cursor-pointer bg-blueish/80",
               ["dashboard", "search"].includes(loc)
                  ? "rounded-lg"
                  : "rounded-full",
               isButtonClicked && "button-click-animation"
            )}
         >
            <GoforwardI className=" aspect-[1] h-[40%] my-auto fill-white m-auto" />
         </button>
      </search>
   )
}
