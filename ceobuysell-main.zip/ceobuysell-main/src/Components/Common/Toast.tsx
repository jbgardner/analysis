import { Toaster } from "react-hot-toast"

export default function Toast() {
   return (
      <Toaster
         position="bottom-right"
         toastOptions={{
            style: {
               background: "#14162d",
               color: "#fff",
               textAlign: "center",
               zIndex: "99999999",
            },
            duration: 3000,
         }}
      />
   )
}

// <Toaster
//    reverseOrder={false}
//    position="bottom-right"
//    toastOptions={{
//       style: { padding: 0 },
//       duration: 2500,
//    }}
// >
//    {(t) => (
//       <ToastBar toast={t}>
//          {({ icon, message }) => (
//             <div className=" flex p-2 items-center  w-full h-full bg-[#eee] dark:bg-[#363636] dark:text-light rounded-md  ">
//                {icon}
//                <span>{message}</span>
//             </div>
//          )}
//       </ToastBar>
//    )}
// </Toaster>
