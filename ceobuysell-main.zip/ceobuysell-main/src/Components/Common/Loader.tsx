import CircularProgress from "@mui/material/CircularProgress"
import clsx from "clsx"
import "../../Styles/loader.css"

type loaderProp = { size: number; className?: string }

export default function Loader({ size, className }: loaderProp) {
   return (
      <div
         className={clsx(
            "grid w-full h-full justify-center items-center z-0",
            className
         )}
      >
         <CircularProgress size={size} />
      </div>
   )
}
export const LineLoader = ({ className }: { className: string }) => {
   return (
      <div className={clsx("  grid items-center", className)}>
         <div className="loader relative w-14 md:w-20 h-4 before:w-4 text-blueish  border border-blueish rounded-full scale-75 "></div>
      </div>
   )
}
