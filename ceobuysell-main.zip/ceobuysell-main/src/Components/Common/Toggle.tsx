import { Switch } from "@headlessui/react"

export const Toggle = ({
   enabled,
   setEnabled,
}: {
   enabled: boolean
   setEnabled: (arg: boolean) => void
}) => (
   <Switch
      checked={enabled}
      onChange={setEnabled}
      className={`${enabled ? "bg-blueish" : "bg-teal-900"}
          relative inline-flex h-[1.275rem] md:h-[1.5rem] w-[2.28rem]  md:w-[2.75rem] shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus-visible:ring-2  focus-visible:ring-white/75`}
   >
      <span className="sr-only">Use setting</span>
      <span
         aria-hidden="true"
         className={`${
            enabled ? "translate-x-4 md:translate-x-5" : "translate-x-0"
         }
            pointer-events-none inline-block h-[1.05rem] md:h-[1.25rem] w-[1.05rem] md:w-[1.25rem] transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out`}
      ></span>
   </Switch>
)
