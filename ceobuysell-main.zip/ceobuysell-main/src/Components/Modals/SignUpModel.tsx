import { motion } from "framer-motion"
import { Fragment, useEffect, useState } from "react"
import { path01Variants, path02Variants } from "../../utils/Constants"
import { LoginI, SignUpI } from "../../assets/Icons/Icons"
import { Popover, Transition } from "@headlessui/react"
import { useAuth } from "../../Hooks/useAuth"
import Loader from "../Common/Loader"

export const SignUpModel = ({
   setModelIndex,
   setOpenModel,
}: {
   setModelIndex: (arg: number) => void
   setOpenModel: (arg: boolean) => void
}) => {
   const [isModalOpen, setIsModalOpen] = useState(false)
   const [animation, setAnimation] = useState("closed")
   const { loading } = useAuth()

   const nav = (index: number) => {
      openCloseModel()
      setModelIndex(index)
      setOpenModel(true)
   }

   const openCloseModel = () => {
      setAnimation("moving")

      setTimeout(() => {
         setAnimation(isModalOpen === false ? "closed" : "open")
         setIsModalOpen(isModalOpen === false ? true : false)
      }, 150)
   }

   return (
      <Popover className="relative md:hidden h-full grid items-center justify-end">
         <Popover.Button
            className=" h-6 w-6  outline-none"
            onClick={openCloseModel}
         >
            {({ open }) => {
               useEffect(() => openCloseModel(), [open])
               return (
                  <svg viewBox="0 0 24 24" radius="100%">
                     <motion.path
                        stroke="#fff"
                        strokeWidth={2.5}
                        animate={animation}
                        variants={path01Variants}
                     />
                     <motion.path
                        stroke="#fff"
                        strokeWidth={2.5}
                        animate={animation}
                        variants={path02Variants}
                     />
                  </svg>
               )
            }}
         </Popover.Button>
         <Transition.Child
            as={Fragment}
            enter="ease-out duration-200"
            enterFrom="opacity-0 translate-x-20 -translate-y-20 scale-50"
            enterTo="opacity-100 scale-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100 scale-100"
            leaveTo="opacity-0 scale-50 translate-x-20  -translate-y-20 "
         >
            <Popover.Panel className="absolute top-16 right-0 z-50 block bg-accents shadow-lg shadow-black/50  p-4 w-[18rem] rounded-md  text-base sm:text-lg">
               {!loading ? (
                  <div className="mx-auto text-lg">
                     <button
                        className="flex justify-between items-center w-full mt-2 py-1 px-3 fill-white border border-blueish transition-all duration-[0.3s]  hover:bg-blueish hover:scale-105 rounded-md"
                        onClick={() => nav(0)}
                     >
                        <div>Login</div>
                        <LoginI className="h-4 " />
                     </button>
                     <button
                        className="flex justify-between items-center w-full mt-2 py-1 px-3 stroke-white border border-blueish transition-all duration-[0.3s]  hover:bg-blueish hover:scale-105 rounded-md"
                        onClick={() => nav(1)}
                     >
                        <div>Sign Up</div>
                        <SignUpI className="h-4 stroke-[1.3] " />
                     </button>
                  </div>
               ) : (
                  <div className="w-full h-20 ">
                     <Loader size={20} />
                  </div>
               )}
            </Popover.Panel>
         </Transition.Child>
      </Popover>
   )
}
