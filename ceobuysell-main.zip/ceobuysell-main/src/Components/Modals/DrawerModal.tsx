import { Link } from "react-router-dom"
import {
   LoginI,
   LogoutI,
   ProfileReplacmentI,
   SignUpI,
} from "../../assets/Icons/Icons"
import { useAuth } from "../../Hooks/useAuth"
import { HeaderNavData } from "../Header&fFooter/HeaderNavData"

interface ModalProps {
   onClose: () => void
}

export const DrawerModal: React.FC<ModalProps> = ({ onClose }) => {
   const { logout, user, setModelIndex, setOpenModel } = useAuth()
   const nav = (index: number) => {
      onClose()
      setModelIndex(index)
      setOpenModel(true)
   }

   return (
      <div className=" mx-2 xs:mx-5 absolute md:hidden w-fit top-[3.8rem] right-0   z-10">
         <div className="fixed inset-0" onClick={onClose}></div>
         <div className="relative  bg-accents p-5 rounded-xl shadow-lg shadow-black/50  ">
            <div className="top-0 right-0 flex">
               {user && (
                  <div className="mx-auto w-[80vw] xs:w-[20rem] text-lg ">
                     <div className="pb-2 border-b border-white/20 ">
                        <div className=" flex justify-between items-end mb-1">
                           <p className=" text-lg sm:text-xl  font-bold leading-7 text-opacity-70 w-full ">
                              Hy, {user.name} 👋
                              <br />
                           </p>
                           {!user.isPro && (
                              <a
                                 href={`${origin}/#pricing`}
                                 className=" w-fit h-fit text-sm xs:text-base font-extrabold grid items-center whitespace-nowrap rounded-full border border-blueish hover:bg-blueish transition-all duration-[0.3s] px-3 lg:px-4 py-1 "
                              >
                                 Go Pro
                              </a>
                           )}
                        </div>
                        <p className=" md:text-lg font-light text-white/80 text-ellipsis overflow-clip w-full">
                           {user?.email}
                        </p>
                     </div>
                     <div className=" flex w-full font-semibold  lg:text-lg mt-2">
                        <Link
                           to={`/search`}
                           className=" transition-all duration-[0.2s] ease-in-out py-1 md:py-0 w-fit border-b border-transparent hover:border-blueish hover:translate-x-3 md:hover:translate-x-0 px-3 md:px-0  "
                        >
                           Search
                        </Link>
                     </div>
                     <HeaderNavData
                        className=" flex flex-col rounded-md font-semibold  lg:text-lg "
                        handleClose={onClose}
                     />

                     <div className=" w-full border-b my-2 border-white/20" />

                     {user.isPro && (
                        <Link
                           to={"/dashboard"}
                           className="  flex justify-between items-center gap-2 my-4 px-3 py1 h-10 rounded-md  w-full  stroke-white border border-blueish transition-all duration-[0.3s]  hover:bg-blueish hover:scale-105 "
                        >
                           Account Prefrences
                           <ProfileReplacmentI className=" h-9 -mr-3 -ml-1 fill-white " />
                        </Link>
                     )}
                     <button
                        onClick={logout}
                        className="flex justify-between items-center w-full mt-2 py-1 px-3 h-10  stroke-white border border-blueish transition-all duration-[0.3s]  hover:bg-blueish hover:scale-105 rounded-md"
                     >
                        <div>Logout</div>
                        <LogoutI className="h-4 stroke-[1.3] " />
                     </button>
                  </div>
               )}

               {!user && (
                  <div className="mx-auto w-[80vw] xs:w-[20rem] text-lg">
                     <HeaderNavData
                        className="flex flex-col transition-all ease-in-out rounded-md font-semibold  lg:text-lg "
                        handleClose={onClose}
                     />
                     <div className=" border-t border-white/20 mt-4 pt-4">
                        <button
                           className="flex justify-between items-center w-full mt-2 py-1 px-3 fill-white border border-blueish transition-all duration-[0.3s]  hover:bg-blueish hover:scale-105 rounded-md"
                           onClick={() => nav(0)}
                        >
                           <div>Login</div>
                           <LoginI className="h-4 " />
                        </button>
                        <button
                           className="flex justify-between items-center w-full mt-2 py-1 px-3 stroke-white border border-blueish transition-all duration-[0.3s]  hover:bg-blueish hover:scale-105 rounded-md"
                           onClick={() => nav(1)}
                        >
                           <div>Sign Up</div>
                           <SignUpI className="h-4 stroke-[1.3] " />
                        </button>
                     </div>
                  </div>
               )}
            </div>
         </div>
      </div>
   )
}
