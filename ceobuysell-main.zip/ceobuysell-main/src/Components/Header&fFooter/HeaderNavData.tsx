import { Link } from "react-router-dom"
import { sectionNavs } from "../../utils/Constants"

interface HeaderProps {
   className?: string
   handleClose?: () => void
}

export const HeaderNavData: React.FC<HeaderProps> = ({
   className,
   handleClose = () => {},
}) => {
   const path = window.location

   return (
      <>
         <nav className={className} onClick={handleClose}>
            {sectionNavs.Pages.map((page, index) => {
               if (path.pathname === "/" && index !== 0) {
                  return (
                     <a
                        key={index}
                        className=" transition-all duration-[0.2s] ease-in-out py-1 md:py-0 w-fit border-b border-transparent hover:border-blueish hover:translate-x-3 md:hover:translate-x-0 px-3 md:px-0  "
                        href={`${path.origin}/${sectionNavs.refIds[index]}`}
                     >
                        {page}
                     </a>
                  )
               } else {
                  return (
                     <Link
                        key={index}
                        to={`/${sectionNavs.refIds[index]}`}
                        className="transition-all duration-[0.2s] ease-in-out py-1 md:py-0 w-fit border-b border-transparent hover:border-blueish hover:translate-x-3 md:hover:translate-x-0 px-3 md:px-0  "
                     >
                        {page}
                     </Link>
                  )
               }
            })}
         </nav>
      </>
   )
}
