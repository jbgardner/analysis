import logo from "../../assets/Icons/Logo.svg"
import { useEffect, useRef, useState } from "react"
import { Link } from "react-router-dom"
import { motion, useInView } from "framer-motion"
import clsx from "clsx"
import { path01Variants, path02Variants } from "../../utils/Constants"
import { DrawerModal } from "../Modals/DrawerModal"
import "../../Styles/header.css"
import { useAuth } from "../../Hooks/useAuth"
import AuthModal from "../Auth/AuthModel"
import { LineLoader } from "../Common/Loader"
import { Account } from "../Common/Account"
import { HeaderNavData } from "./HeaderNavData"
import { useMediaQuery } from "@mui/material"

export const Header = () => {
   const [isModalOpen, setIsModalOpen] = useState(false)
   const [animation, setAnimation] = useState("closed")
   const { user, openModel, setOpenModel, setModelIndex, loading } = useAuth()
   const widthy = useMediaQuery("(min-width:768px)")
   const stickyMaintainerRef = useRef(null)

   const isStickyMaintainerInView = useInView(stickyMaintainerRef)

   useEffect(() => {
      if (widthy) {
         setAnimation("closed")
         setIsModalOpen(false)
      }
   }, [widthy])

   const openModal = () => {
      openCloseModel()
   }

   const openCloseModel = () => {
      setAnimation("moving")

      setTimeout(() => {
         setAnimation(animation === "open" ? "closed" : "open")
         setIsModalOpen(isModalOpen === false ? true : false)
      }, 150)
   }

   const closeModal = () => {
      openCloseModel()
   }

   return (
      <>
         <div
            ref={stickyMaintainerRef}
            className="absolute top-0 w-full h-[66px] "
         ></div>
         <header
            className={clsx(
               " lg:w-[97%] max-w-[92rem] lg:rounded-xl mx-auto ",
               !isStickyMaintainerInView
                  ? " sticky_header bg-accents top-0 lg:top-[0.3rem] shadow-md shadow-black/50"
                  : " sticky z-[9000] "
            )}
         >
            <div className=" mx-auto w-full max-w-maximum px-[1rem] md:px-[1.5rem] xl:px-[5rem]  ">
               <div className="inline-flex justify-between items-center w-full h-14 lg:h-16 ">
                  <Link
                     className=" flex h-full items-center gap-3 md:gap-4 cursor-pointer"
                     to="/"
                  >
                     <img src={logo} className=" h-[85%] -mr-3" alt="Logo" />
                     <h1 className="text-xl xl:text-2xl font-bold whitespace-nowrap flex flex-nowrap">
                        CEOBuySell{" "}
                        <span className="md:hidden min-[800px]:block">
                           .com
                        </span>
                     </h1>
                  </Link>

                  <div className=" md:flex md:gap-3 lg:gap-4 h-full hidden justify-end items-center">
                     <HeaderNavData className="flex items-center gap-3 lg:gap-8 sm:text-lg  xl:text-xl  " />
                     {loading && (
                        <LineLoader className="w-[10.5rem] lg:w-[12.5rem]  xl:w-[13.5rem] grid justify-end items-center h-8" />
                     )}

                     {user && !loading && (
                        <div className=" w-[10.5rem] lg:w-[12.5rem]  xl:w-[13.5rem] h-full flex justify-end gap-3 items-center lg:text-lg  xl:text-xl">
                           {!user.isPro && (
                              <a
                                 href="#pricing"
                                 className=" w-fit hidden md:grid items-center justify-center border border-blueish transition-all duration-[0.3s] font-bold hover:bg-blueish px-3 lg:px-4 py-1 rounded-xl"
                              >
                                 Go Pro
                              </a>
                           )}
                           {user.isPro && (
                              <Link
                                 to="/search"
                                 className=" w-fit hidden md:grid items-center justify-center border border-blueish transition-all duration-[0.3s] font-bold hover:bg-blueish px-3 lg:px-4 py-1 rounded-xl"
                              >
                                 Search
                              </Link>
                           )}
                           <div className=" relative ">
                              <Account />
                           </div>
                        </div>
                     )}
                     {!user && !loading && (
                        <div className=" w-[10.5rem] lg:w-[12.5rem]  xl:w-[13.5rem] flex items-center justify-end text-base lg:text-lg gap-1 lg:gap-2">
                           <button
                              className=" w-fit transition-all duration-[0.3s] hover:text-white text-blueish hover:bg-blueish hover:scale-x-105 px-3 py-1 rounded-md"
                              onClick={() => {
                                 setOpenModel(true)
                                 setModelIndex(0)
                              }}
                           >
                              Login
                           </button>
                           <button
                              className=" w-fit border border-blueish transition-all duration-[0.3s]  hover:bg-blueish hover:scale-105 px-3 py-1 rounded-md"
                              onClick={() => {
                                 setOpenModel(true)
                                 setModelIndex(1)
                              }}
                           >
                              Sign Up
                           </button>
                        </div>
                     )}
                  </div>
                  <div
                     className="cursor-pointer block  md:hidden h-6 w-6  "
                     onClick={openModal}
                  >
                     <svg viewBox="0 0 24 24" radius="100%">
                        <motion.path
                           stroke="#fff"
                           strokeWidth={2.5}
                           animate={animation}
                           variants={path01Variants}
                        />
                        <motion.path
                           stroke="#fff"
                           strokeWidth={2.5}
                           animate={animation}
                           variants={path02Variants}
                        />
                     </svg>
                  </div>
                  {/* Modals */}
                  {isModalOpen && <DrawerModal onClose={closeModal} />}
               </div>
            </div>
            <AuthModal open={openModel} setOpen={setOpenModel} />
         </header>
      </>
   )
}
