import { FC } from "react"
import { CircularTick } from "../../assets/Icons/Icons"
import { footer } from "../../utils/Constants"
import { SearchBar } from "../Common/SearchBar"
import { Link } from "react-router-dom"

interface FooterProp {
   addSearchBar?: boolean
}

export const Footer: FC<FooterProp> = ({ addSearchBar = false }) => (
   <footer id="footer" className="w-full h-auto bg-darkbg/40 relative ">
      <div className=" max-w-maximum mx-auto pt-5 pb-[0.5rem]">
         {addSearchBar && (
            <>
               <h2 className="px-5 md:px-0 text-center font-bold text-title2 sm:text-title1">
                  {footer.title}
               </h2>
               <p className=" mx-auto my-6  min-w-[200px] px-4 md:px-0  w-full sm:w-[55%]  md:text-lg lg:text-lg text-center">
                  {footer.para[0]}
                  <Link to="/search" className=" text-blueish">
                     {footer.para[1]}
                  </Link>
               </p>
               <SearchBar className="my-4  mx-auto xs:min-w-[400px] w-[90%] xs:w-[70%] focus-within:scale-105 rounded-[23.8px] " />
               <div className=" w-full flex  justify-center flex-wrap gap-3 md:gap-4 mt-7 ">
                  {footer.pills.map((item, index) => (
                     <div
                        key={index}
                        className=" flex gap-2 items-center transition-colors bg-darkbg hover:bg-blueish cursor-default rounded-full px-4 py-2"
                     >
                        <CircularTick className=" h-4" />
                        <span>{item.label}</span>
                     </div>
                  ))}
               </div>
            </>
         )}
         <div className=" flex flex-wrap sm:flex-nowrap justify-center sm:justify-normal text-center sm:text-left text-lightgray text-sm sm:text-base sm:leading-[1.63rem] mt-6">
            <p className=" sm:w-1/2 m-2 sm:m-10">
               The data provided on this site is for informational purposes
               exclusively. It does not constitute professional financial,
               investment, or legal advice in any regard. Users should seek
               guidance from licensed experts prior to making decisions.
               <br className=" mb-4" />
               No results or specific outcomes can be guaranteed from usage of
               information presented in
               <span className=" font-bold text-white"> CEOBuySell.com</span>.
               Past returns not indicative of future gains. Investments
               inherently bear risks including potential loss of capital.
            </p>
            <p className="sm:w-1/2 m-2 sm:m-10">
               We recommend consulting a personal financial advisor and fully
               vetting any investments yourself before deciding to trade. Every
               individual's position differs.
               <br className=" mb-4" />
               Content is provided “as is” without warranties express or
               implied. Usage constitutes acceptance of sole responsibility for
               risk associated with application of content. No attorney-client
               privilege exists through utilization of services rendered. Users
               assume accountability for individual decisions based on material
               accessed.
            </p>
         </div>
         <div
            className={`${
               !addSearchBar && "mb-[15%]"
            } border-t border-white/30 mt-5 sm:mt-0 relative`}
         >
            <div className=" flex flex-wrap sm:flex-nowrap justify-center sm:justify-between text-center sm:text-left  mt-4 px-4 md:px-6">
               <p className="">
                  Copyright © {new Date().getFullYear()} CEOBuySell.com All
                  Rights Reserved. Email: info@ceobuysell.com
               </p>
               <p className="">Built with ❤️ in New York</p>
            </div>
         </div>
      </div>
   </footer>
)
