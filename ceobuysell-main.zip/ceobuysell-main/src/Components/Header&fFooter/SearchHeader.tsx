// hooks
import { Link, useLocation } from "react-router-dom"
import { useAuth } from "../../Hooks/useAuth"

// assets
import logo from "../../assets/Icons/Logo.svg"
import "../../Styles/header.css"

// Components
import { SearchBar } from "../Common/SearchBar"
import { LineLoader } from "../Common/Loader"
import { Account } from "../Common/Account"
import AuthModal from "../Auth/AuthModel"
import { SignUpModel } from "../Modals/SignUpModel"

//helper
import clsx from "clsx"
import { useInView } from "framer-motion"
import { useRef } from "react"

export function SearchHeader() {
   const { user, loading, setModelIndex, setOpenModel, openModel } = useAuth()

   const { pathname } = useLocation()
   const loc = pathname.split("/")[1]
   const { origin } = window.location

   const stickyMaintainerRef = useRef(null)

   const isStickyMaintainerInView = useInView(stickyMaintainerRef)

   return (
      <>
         <div
            ref={stickyMaintainerRef}
            className="absolute top-0 w-full h-[66px] "
         ></div>
         <header
            className={clsx(
               " lg:w-[97%] max-w-[92rem] lg:rounded-xl mx-auto   ",
               !isStickyMaintainerInView
                  ? " sticky_header bg-accents top-0 lg:top-[0.3rem] shadow-md shadow-black/50"
                  : " sticky z-[9000] "
            )}
         >
            <div className=" mx-auto w-full max-w-maximum px-[1rem] md:px-[1.5rem] xl:px-[5rem]  ">
               <div className="inline-flex justify-between items-center w-full h-14 lg:h-16 ">
                  {/* ============================= LOGO ============================= */}
                  <Link
                     className=" flex shrink-0 md:shrink w-[3.4rem] md:w-[20rem] items-center gap-4 h-full cursor-pointer"
                     to="/"
                  >
                     <img src={logo} className=" h-[85%] -mr-3" alt="Logo" />
                     <h1 className="hidden md:flex flex-nowrap text-xl xl:text-2xl font-bold whitespace-nowrap ">
                        CEOBuySell
                        <span className="md:hidden min-[1000px]:block">
                           .com
                        </span>
                     </h1>
                  </Link>

                  {/* ============================= SEARCH BAR ============================= */}
                  <div className="grid items-center transition-all duration-200 ease-linear w-full h-full sm:text-lg ">
                     <SearchBar
                        className=" grid  items-center w-full mx-auto lg:translate-x-6 max-w-[34rem] h-[65%] rounded-lg "
                        inputClassName="h-full xs:text-lg  pl-11 pr-11 text-white bg-inputColor  w-full outline-none"
                     />
                  </div>

                  {/* ============================= USER & NAV ============================= */}
                  <div
                     className={` relative w-[4rem] md:w-[18rem] grid justify-end items-center h-full `}
                  >
                     {/* ======= LOADER =======  */}
                     {loading && (
                        <LineLoader className=" w-full -mr-[2px] md:mr-0 grid justify-end items-center h-8" />
                     )}

                     {/* ======= USER LOGED =======  */}
                     {user && !loading && (
                        <div className="  w-full flex justify-end gap-3 items-center lg:text-lg  xl:text-xl">
                           {!user.isPro &&
                              ["dashboard", "search"].includes(loc) && (
                                 <a
                                    href={`${origin}/#pricing`}
                                    className=" w-full hidden md:grid items-center justify-center border border-blueish transition-all duration-[0.3s] font-extrabold hover:bg-blueish px-3 lg:px-4 py-1 rounded-xl"
                                 >
                                    Go Pro
                                 </a>
                              )}
                           <Account />
                        </div>
                     )}

                     {/* ======= USER UNKNOWN =======  */}
                     {!user && !loading && (
                        // ======= USER UNKNOWN MODEL =======
                        <SignUpModel
                           setModelIndex={setModelIndex}
                           setOpenModel={setOpenModel}
                        />
                     )}
                     {!user && !loading && (
                        <div className=" w-full hidden md:flex items-center justify-end text-base lg:text-lg gap-1 lg:gap-2">
                           <button
                              className=" w-fit transition-all duration-[0.3s] hover:text-white text-blueish hover:bg-blueish hover:scale-x-105 px-3 py-1 rounded-md"
                              onClick={() => {
                                 setOpenModel(true)
                                 setModelIndex(0)
                              }}
                           >
                              Login
                           </button>
                           <button
                              className=" w-fit border border-blueish whitespace-nowrap transition-all duration-[0.3s] hover:bg-blueish hover:scale-105 px-3 py-1 rounded-md"
                              onClick={() => {
                                 setOpenModel(true)
                                 setModelIndex(1)
                              }}
                           >
                              Sign Up
                           </button>
                        </div>
                     )}
                  </div>
               </div>
               {/* ============================= AUTH MODAL ============================= */}
               <AuthModal open={openModel} setOpen={setOpenModel} />
            </div>
         </header>
      </>
   )
}
