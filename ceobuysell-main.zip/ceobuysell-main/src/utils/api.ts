// export const API_BASE_URL = "http://localhost:8002/"
// export const API_BASE_URL = "https://7nvtj2c0-8000.euw.devtunnels.ms/"
export const API_BASE_URL = "https://api.ceobuysell.com"
