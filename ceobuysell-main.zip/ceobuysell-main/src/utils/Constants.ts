import iphone from "../assets/Images/iphoneMsg.webp"
import key from "../assets/Images/key.svg"
import getnotified from "../assets/Images/getnotified.svg"
import review from "../assets/Images/Review.svg"
import wishlist from "../assets/Images/wishlist.svg"
import story_01 from "../assets/Images/story_01.svg"
import story_02 from "../assets/Images/story_02.svg"
import story_03 from "../assets/Images/story_03.svg"
import features_01 from "../assets/Images/features_01.svg"
import features_02 from "../assets/Images/features_02.svg"
import features_03 from "../assets/Images/features_03.svg"
import features_04 from "../assets/Images/features_04.svg"
import jessica from "../assets/Images/Jessica.svg"
import jacob from "../assets/Images/jacob.svg"
import roy from "../assets/Images/Roy.svg"
import samuel from "../assets/Images/Samuel.svg"
import darren from "../assets/Images/Darren.svg"

export const stories = {
   title: "Success Stories",
   para: "Here are just a few examples of successful trades with substantial returns.",

   stories: [
      {
         title: "💰 Fulgent Genetics, Inc. -FLGT",
         para: [
            "CEO Hsieh Ming bought ",
            "8,739",
            " shares at ",
            "$4.95",
            " for a total of ",
            "$43,258",
            ". If you hadinvested ",
            "$1,000",
            " when the news came out, your investment would have been worth ",
            "$1,208 after 1 month",
            " and ",
            "$2,420 after 6 months.",
         ],
         imgeUrl: story_01,
      },
      {
         title: "💰 Shotspotter, Inc -SSTI",
         para: [
            "CEO Clark Ralph A. bought ",
            "1,500",
            " shares at ",
            "$18.73",
            " for a total of ",
            "$28,095",
            ". If you had invested ",
            "$1,000",
            " when the news came out, your investment would have been worth ",
            "$1,277 after 1 month",
            " and ",
            "$2,397 after 6 months.",
         ],
         imgeUrl: story_03,
      },
      {
         title: "💰 Enphase Energy, Inc. -ENPH",
         para: [
            "CEO Kothandaraman Badrinarayanan bought ",
            "10,000",
            " shares at ",
            "$8.70",
            " for a total of ",
            "$87,000",
            ". If you had invested",
            " $1,000",
            " when the news came out, your investment would have been worth ",
            "$1,131 after 1 month",
            " and ",
            "$2,907 after 6 months.",
         ],
         imgeUrl: story_02,
      },
      // {
      //    title: "💰 Francesca's Holdings Corp -FRAN",
      //    para: [
      //       "CEO Kunes Richard W bought ",
      //       "20,000",
      //       " shares at ",
      //       "$10.11",
      //       " for a total of ",
      //       "$202,200",
      //       ". If you had invested ",
      //       "$1,000",
      //       " when the news came out, your investment would have been worth ",
      //       "$1,229 after 1 month",
      //       " and ",
      //       "$2,094 after 6 months.",
      //    ],
      //    imgeUrl: story_04,
      // },
      // {
      //    title: "💰 W&t Offshore Inc -WTI",
      //    para: [
      //       "CEO Krohn Tracy W bought ",
      //       "132,134",
      //       " shares at ",
      //       "$1.86",
      //       " for a total of ",
      //       "$245,769",
      //       ". If you had invested ",
      //       "$1,000",
      //       " when the news came out, your investment would have been worth ",
      //       "$1,608 after 1 month",
      //       " and ",
      //       "$2,151 after 6 months.",
      //    ],
      //    imgeUrl: story_05,
      // },
      // {
      //    title: "💰 Biosig Technologies, Inc. -BSGM",
      //    para: [
      //       "CEO Kenneth Londoner bought ",
      //       "8,500",
      //       " shares at ",
      //       "$4.21",
      //       " for a total of ",
      //       "$35,785",
      //       ". If you had invested ",
      //       "$1,000",
      //       " when the news came out, your investment would have been worth ",
      //       "$1,019 after 1 month",
      //       " and ",
      //       "$2,124 after 6 months.",
      //    ],
      //    imgeUrl: story_06,
      // },
   ],
}

export const pricing = {
   title: "Very Simple Pricing.",
   plans: [
      {
         name: "monthly",
         title: "Monthly Pass",
         price: "$25",
         beforePrice: "",
         features: [
            "Real-time notifications when CEOs buy/sell shares",
            "Custom CEO & Company Alerts",
            "Daily Digest Email Updates",
            "View track records and past performance of each CEO to fuel your strategies",
            "Advanced Filtering Tools",
            "Searchable Raw Data Feeds",
         ],
      },
      {
         name: "yearly",
         title: "Yearly Pass",
         price: "$200",
         beforePrice: "",
         features: [
            "Real-time notifications when CEOs buy/sell shares",
            "Custom CEO & Company Alerts",
            "Daily Digest Email Updates",
            "View track records and past performance of each CEO to fuel your strategies",
            "Advanced Filtering Tools",
            "Searchable Raw Data Feeds",
         ],
      },
      {
         name: "lifetime",
         title: "Lifetime Pass",
         price: "$350",
         beforePrice: "",
         features: [
            "Real-time notifications when CEOs buy/sell shares",
            "Custom CEO & Company Alerts",
            "Daily Digest Email Updates",
            "View track records and past performance of each CEO to fuel your strategies",
            "Advanced Filtering Tools",
            "Searchable Raw Data Feeds",
         ],
      },
   ],
}

export const feature = {
   featursImage: [features_01, features_02, features_03, features_04],
   title: "Our Features",
   featureCards: [
      {
         title: "Get Daily digest & reports ",
         para: " Receive the day's recap every evening to stay current and sector analysis reports each Saturday to plan ahead.",
      },
      {
         title: "See past wins at a glance",
         para: "See Every CEO's Trading History. Gauge patterns and performance over time to make informed investment decisions",
      },
      {
         title: "Smart search & filters",
         para: "Tune Insider Alerts using our advanced search filters to match your interests. Filter by company, sector, market cap, share price, share count, volume and other key criteria. Get only the most relevant activity on your radar.",
      },
      {
         title: "Custom Watchlists",
         para: "Hand pick companies and CEOs you want to track based on sectors, trade size, or leader profiles. Get notifications only when they make relevant moves. Cuts noise so you catch meaningful activity.",
      },
   ],
}

export const footer = {
   title: "Getting Started",
   para: [
      "To get started receiving real-time alerts when a CEO buys or sells, start by looking up a company or",
      " browse all buys or sells.",
   ],
   pills: [
      { label: " Smart Filters" },
      { label: "Text Notifications" },
      { label: "Email Notifications" },
      { label: "️Daily Digests" },
      { label: "Real-Time" },
   ],
}

export const howitworks = {
   title: "How It Works",
   para: "CEOs might sell their stock for many reasons, but they only buy for one: they believe the price is going up. We track every move they make for you.",
   cards: [
      {
         title: "Sign Up",
         para: "Choose Your Plan, Create Your Account. Customize Your Insider Notification Alerts",
         imageUrl: key,
      },
      {
         title: "Make a Watchlist",
         para: "Use intel to fuel smart decisions. Enjoy the returns.",
         imageUrl: wishlist,
      },
      {
         title: "Get Notified Of Insider Moves",
         para: "Get real-time alerts instantly when CEOs buy or sell shares.",
         imageUrl: getnotified,
      },
      {
         title: "Review and Decide Your Move",
         para: "Use intel to fuel smart decisions. Enjoy the returns.",
         imageUrl: review,
      },
   ],
}

export const defaultSettings = {
   email_notification: true,
   text_notification: false,
   daily_digest: true,
   weekly_sector_report: true,
}

export const testimonials = {
   title: "What our customers says",
   cards: [
      {
         image: jessica,
         author: "Jessica C.",
         jobTitle: "Finance Major",
         para: "As a college student new to investing, the insider trading alerts help level the playing field so I can make informed trades just like the experts. I also leverage the aggregated executive transaction trends to identify macroeconomic shifts faster for my essays and case competitions",
      },
      {
         image: samuel,
         author: "Samuel W.",
         jobTitle: "Individual Investor",
         para: "As a new retail investor, getting mobile push notifications the moment executives buy or sell shares of their own stock takes much of the guesswork and risk out of my personal trades. Now I can mirror the behaviors of marquee CEOs I follow at major public companies before market movements.",
      },
      {
         image: jacob,
         author: "Jacob M.",
         jobTitle: "Financial Assistant",
         para: "With lagging indicators like quarterly filings, I’m always looking for an edge to assess shifts faster. This tool fills the gap, letting me incorporate both quantitative and qualitative signals from how insiders are actually trading right now. As a researcher, having transparent access to CEO transactions raises my analysis to another level.",
      },
      {
         image: roy,
         author: "Roy K.",
         jobTitle: "Active Investor",
         para: "As a day trader relying on splitting-second decisions, the real-time CEO trade alerts from this platform give me an invaluable information advantage to base my savvy market moves on. By combining these insider transaction signals with sophisticated charting analysis, I've developed a sharper edge to base my savviest market moves on.",
      },
      {
         image: darren,
         author: "Darren L.",
         jobTitle: "Creator",
         para: "As a financial writer and podcaster, getting alerted to insider trading scoops first gives me a consistent edge on breaking news for my large audience across web, social media, video and audio platforms. Rather than wait for mainstream outlets, I rapidly publish motivations behind big CEO moves to capture eyeballs and uniquely showcase my insider relationships in this competitive niche.",
      },
   ],
}

export const hero = {
   title: ["CEOs Know More Than You Think.", " Get The Inside Scoop."],
   para0: [
      "Get ",
      "notifications in real-time ",
      "when CEOs make big stock moves, so you can trade alongside the insiders. ",
      "Level the playing field using advanced AI.",
   ],
   placeHolder: "TSLA, INTC, GE, JPM",
   para1: "Giving the Little Guy a Fighting Chance.",
   imageUrl: iphone,
}

export const sectionNavs = {
   Pages: ["Home", "Overview", "Features", "Pricing", "Blog"],
   refIds: ["", "#howitworks", "#features", "#pricing", "#blog"],
}

export const examples = [
   {
      text: "Anytime a CEO buys at least 1,000 shares.",
      paramValue: "/search?share_count_min=1000",
   },
   {
      text: "Anytime a CEO spends at least $500,000.",
      paramValue: "/search?total_amount_min=500000",
   },
   {
      text: "Anytime a CEO buys shares below $10.00.",
      paramValue: "/search?share_price_max=10",
   },
   {
      text: "Anytime a CEO sells shares below $100.00.",
      paramValue: "/search?share_price_max=10&transaction_type=S",
   },
]

export const path01Variants = {
   open: { d: "M3.06061 2.99999L21.0606 21" },
   closed: { d: "M0 9.5L24 9.5" },
}

export const path02Variants = {
   open: { d: "M3.00006 21.0607L21 3.06064" },
   moving: { d: "M0 14.5L24 14.5" },
   closed: { d: "M0 14.5L15 14.5" },
}

export const sortMap = [
   "",
   "Most Recent Disclosure First",
   "Oldest Disclosure First",
   "Largest Amount First",
   "Smallest Amount First",
   "Largest Share Price First",
   "Smallest Share Price First",
   "Largest Share Count First",
   "Smallest Share Count First",
   "Largest Ownership Increase/Decrease First",
   "Smallest Ownership Increase/Decrease First",
]

export const marketCapMap = ["Micro", "Small", "Mid", "Large"]

export const sectorsMap = [
   "All Sectors",
   "Real Estate",
   "Health Care",
   "Materials",
   "Industrials",
   "Energy",
   "Consumer Cyclical",
   "Utilities",
   "Consumer Defensive",
   "Financials",
   "Information Technology",
   "Telecommunication Services",
]
