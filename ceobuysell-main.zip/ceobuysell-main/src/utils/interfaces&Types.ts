import { ReactNode } from "react"

export type AuthContextT = {
   user: null | UserT
   setUser: (arg: UserT) => void
   login: (credentials: { email: string; password: string }) => void
   register: (credentials: {
      email: string
      password: string
      name: string
      plan: string
   }) => void
   logout: () => void
   loading: boolean
   openModel: boolean
   setOpenModel: (arg: boolean) => void
   modelIndex: number
   setModelIndex: (arg: number) => void
   customNotifications: customNotificationsT[] | null
   fetchCustomNotifications: (id: string) => Promise<void>
}

export type filtersModalPropsT = ModalPropsT & {
   filters: searchDataT
   setFilter: React.Dispatch<React.SetStateAction<searchDataT>>
   disabled?: boolean
}

export type ModalPropsT = {
   open: boolean
   setOpen: (open: boolean) => void
}

export type extendedSearchDataT = searchDataT & {
   [key: string]: string | number | undefined
}

export type searchDataT = filtersT & {
   sort?: number
   offset?: number
   transaction_type?: string
}

export type filtersT = {
   ticker?: string
   q?: string
   sector?: number
   market_cap?: number
   share_count_min?: number
   share_count_max?: number
   share_price_min?: number
   share_price_max?: number
   total_amount_min?: number
   total_amount_max?: number
   total_share_owned_min?: number
   total_share_owned_max?: number
   ownership_increase_min?: number
   ownership_increase_max?: number
   total_share_min?: number
   total_share_max?: number
}

export type customNotificationsT = filtersT & {
   settings: { email_notification: boolean; text_notification: boolean }
   id: string
   created_at: string
   user_id: string
   transaction_type?: string
}

export type transactionsT = {
   change_in_shares_percentage: number
   one_month_return?: number | null
   one_week_return?: number | null
   six_months_return?: number | null
   share_price: number
   total_amount_spent: number
   total_shares: number
   total_shares_after_transaction: number
   ceo_name: string
   company_name: string
   disclosed_date: string
   formatted_date: string
   id: string
   ticker: string
   transaction_type: string
   link?: string
}

export type UserT = {
   user_id: string
   id: string
   email?: string
   name: string
   settings: settingsT
   subscription_id?: string
   phone?: string
   isPro: boolean
   watchlist?: string[]
   has_lifetime_access: boolean
   plan: string
   customer_id?: string
   watchlist_notification: {
      email_notification: boolean
      text_notification: boolean
   }
}

export type settingsT = {
   email_notification: boolean
   text_notification: boolean
   daily_digest: boolean
   weekly_sector_report: boolean
}

export type searchBarProps = {
   // setSearchResult: (arg: string) => void
   // searchResult: string
   inputClassName?: string | undefined
   className: string | null
}

export type ContextPropsT = {
   children: ReactNode | ReactNode[]
}

export interface ClassProps {
   className?: string
}

export type SearchContextT = { fetching: boolean }
