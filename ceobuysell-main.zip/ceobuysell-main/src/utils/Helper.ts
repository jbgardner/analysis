import { Nullable } from "tryghost__content-api"
import moment from "moment"
import {
   customNotificationsT,
   extendedSearchDataT,
   filtersT,
   searchDataT,
} from "./interfaces&Types"

export function getConciseDate(dateString: Nullable<string> | undefined) {
   if (dateString) {
      // "Mon, 25 Sep 2023 01:26:39 GMT"
      const date = moment(
         new Date(dateString),
         "ddd, DD MMM YYYY HH:mm:ss [GMT]",
         "en"
      )
      return date.format("MMM DD, YYYY")
   } else return null
}

export function getConciseDateAndTime(dateString: string | undefined) {
   if (dateString) {
      // "Mon, 25 Sep 2023 01:26:39 GMT"
      // const d = "2024-02-02T19:33:59+00:00"
      const date = moment(new Date(dateString))
      const dateAndTime = {
         date: date.format("MMM DD, YYYY"),
         time: date.format(" hh:mm a"),
      }

      return dateAndTime
   } else return null
}

export const debounce = <F extends (...args: any[]) => any>(
   func: F,
   delay: number
) => {
   let timeoutId: ReturnType<typeof setTimeout>

   return function (this: ThisParameterType<F>, ...args: Parameters<F>): void {
      clearTimeout(timeoutId)
      timeoutId = setTimeout(() => func.apply(this, args), delay)
   }
}

export const urlInitializer = (
   param: string,
   defaultValue: any,
   searchParams: URLSearchParams
) => {
   const toReturn = searchParams.get(param)

   return toReturn !== null ? toReturn : defaultValue
}

export function getTimeDifference(eventDate: string) {
   const currentDate = new Date()
   const eventDateTime = new Date(eventDate)

   const timeDifferenceInMilliseconds =
      currentDate.getTime() - eventDateTime.getTime()

   const seconds = Math.floor(timeDifferenceInMilliseconds / 1000)
   const minutes = Math.floor(seconds / 60)
   const hours = Math.floor(minutes / 60)
   const days = Math.floor(hours / 24)
   const weeks = Math.floor(days / 7)
   const months = Math.floor(days / 30)
   const years = Math.floor(days / 365)

   if (seconds < 60) {
      return `${seconds} seconds ago`
   } else if (minutes < 60) {
      return `${minutes} minutes ago`
   } else if (hours < 24) {
      return `${hours} hours ago`
   } else if (days < 7) {
      return `${days} days ago`
   } else if (days < 32) {
      return `${weeks} weeks ago`
   } else if (months < 12) {
      return `${months} months ago`
   } else {
      return `${years} years ago`
   }
}

export const stringCleaner = (input: string) => {
   const cleanedString = input.replace(/[^a-zA-Z0-9, ]/g, "").toUpperCase()
   const removesExtraCommas = cleanedString
      .replace(/\s+/g, ",") // replaces space with comma
      .replace(/^,+|,+$|,+/g, ",") // removes Consecutive commas
      .replace(/^,+|,+$/g, "") // leading and ending commas
   return removesExtraCommas
}

export function removeDuplicates(arr: string[]) {
   const seen = new Set()
   return arr.filter((item) => {
      if (!seen.has(item)) {
         seen.add(item)
         return true
      }
      return false
   })
}

export function customNotificationToFilters(
   data: customNotificationsT
): filtersT {
   const { settings, created_at, id, user_id, ...filtersData } = data
   return filtersData
}

// Function to convert searchDataT to filtersT
export function searchDataToFilters(data: searchDataT): filtersT {
   const { sort, offset, ...filtersData } = data
   return filtersData
}

export function filtersExistsInCustomNotifications(
   object: searchDataT,
   array: customNotificationsT[] | null
) {
   if (!array) return false

   const filter = searchDataToFilters(object)

   for (let i = 0; i < array.length; i++) {
      const customNotification = customNotificationToFilters(array[i])
      // console-log(i, isEqual(filter, customNotification))

      if (isEqual(filter, customNotification)) {
         // console-log("\n\n\nkuch to hua ha\n\n\n")

         return true
      }
   }
   return false
}

// Helper function to check equality of two objects
function isEqual(obj1: any, obj2: any) {
   // const keys1 = Object.keys(obj1)
   const keys2 = Object.keys(obj2)

   for (let key of keys2) {
      if (obj1[key] && obj2[key] === null) {
         return false
      }
      if (obj1[key] != obj2[key] && obj2[key] !== null) {
         // console-log(" 2 at:", key, "\n", obj1[key], obj2[key], "\n\n")
         return false
      }
   }

   return true
}

export const convertFormDataToSearchData = (
   formData: FormData
): searchDataT => {
   const filters: extendedSearchDataT = {}

   formData.forEach((value, key) => {
      const sectorIsZero =
         (key as keyof extendedSearchDataT) === "sector" && value === "0"
      const sortIsZero =
         (key as keyof extendedSearchDataT) === "sort" && value === "0"
      const MarketCapIsZero =
         (key as keyof extendedSearchDataT) === "market_cap" && value === "0"

      if (value !== "" && !sectorIsZero && !sortIsZero && !MarketCapIsZero) {
         if (
            key.endsWith("_min") ||
            key.endsWith("_max") ||
            ["sector", "market_cap", "sort"].includes(key)
         ) {
            filters[key as keyof extendedSearchDataT] = parseInt(
               value as string,
               10
            )
         } else if (key === "ticker") {
            filters[key as keyof extendedSearchDataT] = stringCleaner(
               value as string
            )
         } else {
            filters[key as keyof extendedSearchDataT] = value as string
         }
      }
   })

   return filters
}

export const urlsInitializer = (searchParams: URLSearchParams) => {
   const filters: extendedSearchDataT = {}

   searchParams.forEach((value, key) => {
      const sectorIsZero = key === "sector" && value === "0"

      const sortIsZero =
         (key as keyof extendedSearchDataT) === "sort" && value === "0"

      if (value !== "" && !sortIsZero && !sectorIsZero) {
         if (
            key.endsWith("_min") ||
            key.endsWith("_max") ||
            ["sector", "offset", "market_cap", "sort"].includes(key)
         ) {
            filters[key] = parseInt(value as string, 10)
         } else if (key === "ticker") {
            filters[key] = value as string
         } else {
            filters[key] = value as string
         }
      }
   })

   const tT = searchParams.get("transaction_type")

   if (tT === "" || tT === null) {
      filters.transaction_type = "P"
   }

   return filters
}

export const removeExtraFloat = (value: number | null | undefined) => {
   if (!value) return value
   return value % 1 === 0 ? value : parseFloat(value.toFixed(3))
}
export const addPlus = (value: number | null | undefined) => {
   return value ? (value > 0 ? "+" + value + "%" : value + "%") : "--"
}

export const capitalize = (sentence: string) => {
   // Split the sentence into an array of words
   let words = sentence.split(" ")

   // Capitalize each word in the array
   let capitalizedWords = words.map((word) => {
      // Capitalize the first letter of each word and concatenate with the rest of the word
      return word.charAt(0).toUpperCase() + word.slice(1)
   })

   // Join the capitalized words back into a sentence
   let capitalizedSentence = capitalizedWords.join(" ")

   return capitalizedSentence
}
